<?php
declare(strict_types=1);

namespace App\PROJECTS\Managers;

use App\PROJECTS\Repos\PdoProjectDocumentRepository;
use App\PROJECTS\Repos\PdoProjectRepository;
use App\Repos\PdoClientActivityRepository;
use PDO;
use RuntimeException;
use Throwable;

final class ProjectDocumentApprovalManager
{
    private PdoProjectDocumentRepository $documents;
    private PdoProjectRepository $projects;
    private PdoClientActivityRepository $activity;

    public function __construct(
        private PDO $pdo
    ) {
        $this->documents =
            new PdoProjectDocumentRepository($this->pdo);

        $this->projects =
            new PdoProjectRepository($this->pdo);

        $this->activity =
            new PdoClientActivityRepository($this->pdo);
    }

    /**
     * @return array<string, mixed>
     */
    public function approve(int $documentId): array
    {
        if ($documentId <= 0) {
            throw new RuntimeException(
                'Valid document ID required.'
            );
        }

        $document =
            $this->documents->findById($documentId);

        if ($document === null) {
            throw new RuntimeException(
                'Project document was not found.'
            );
        }

        if (empty($document['approval_required'])) {
            throw new RuntimeException(
                'This project document does not require approval.'
            );
        }

        // Repeated approval is idempotent and must not create duplicate activity.
        if ($document['accepted_at'] !== null) {
            return $document;
        }

        $projectId =
            (int)($document['project_id'] ?? 0);

        if ($projectId <= 0) {
            throw new RuntimeException(
                'Project document has no valid project.'
            );
        }

        $project =
            $this->projects->findById($projectId);

        if ($project === null) {
            throw new RuntimeException(
                'Project for this document was not found.'
            );
        }

        $clientId =
            (int)($project['client_id'] ?? 0);

        if ($clientId <= 0) {
            throw new RuntimeException(
                'Project client is required to record document approval.'
            );
        }

        $clientName =
            trim((string)($project['client_name'] ?? ''));

        $documentTitle =
            trim((string)($document['title'] ?? ''));

        if ($documentTitle === '') {
            $documentTitle = 'Document';
        }

        $summary =
            $clientName !== ''
                ? "{$documentTitle} Approved by {$clientName}"
                : "{$documentTitle} Approved";

        $startedTransaction = false;

        try {
            if (!$this->pdo->inTransaction()) {
                $this->pdo->beginTransaction();
                $startedTransaction = true;
            }

            $acceptedDocument =
                $this->documents->accept($documentId);

            $this->activity->create([
                'client_id' => $clientId,
                'project_id' => $projectId,
                'activity_type' => 'document_approved',
                'summary' => $summary,
                'details' => null,
                'related_client_email_id' => null,
                'metadata_json' => json_encode(
                    [
                        'document_id' => $documentId,
                        'document_type' =>
                            (string)(
                                $acceptedDocument['document_type']
                                ?? ''
                            ),
                        'template_key' =>
                            (string)(
                                $acceptedDocument['template_key']
                                ?? ''
                            ),
                    ],
                    JSON_UNESCAPED_SLASHES
                ),
                'occurred_at' =>
                    $acceptedDocument['accepted_at']
                    ?? null,
            ]);

            if ($startedTransaction) {
                $this->pdo->commit();
            }

            /*
             * Add display-only client information to the response.
             * This is not persisted on project_documents.
             */
            $acceptedDocument['approved_by'] =
                $clientName;

            return $acceptedDocument;
        } catch (Throwable $e) {
            if (
                $startedTransaction
                && $this->pdo->inTransaction()
            ) {
                $this->pdo->rollBack();
            }

            throw $e;
        }
    }
}
