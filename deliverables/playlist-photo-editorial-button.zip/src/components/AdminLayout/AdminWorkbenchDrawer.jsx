import useOverlayLifecycle from "../../hooks/useOverlayLifecycle";
import { useState } from "react";
import useAdminMobile from "./useAdminMobile";
import MobileWorkbenchDrawer from "./mobile/MobileWorkbenchDrawer";
import { createPortal } from "react-dom";

function cssSize(value, fallback) {
  if (value === null || value === undefined || value === "") {
    return fallback;
  }

  return typeof value === "number"
    ? `${value}px`
    : String(value);
}

function DesktopWorkbenchDrawer({
  open,
  width = 380,
  title = "",
  onClose,
  closeLabel = "Save & Close",
  beforeClose = null,
  children,
  footer = null,
  actions = null,
  portal = false,
  padded = false,
  className = "",
}) {
  const [closing, setClosing] = useState(false);

  const overlayRef = useOverlayLifecycle({
    open: open && portal, layer: "drawer", modal: false, autoFocus: false,
    onEscape: () => void requestClose(),
  });

  if (!open) return null;

  const cssWidth = cssSize(width, "380px");

  async function requestClose() {
    if (!onClose || closing) return;

    setClosing(true);

    try {
      if (typeof beforeClose === "function") {
        const result = await beforeClose();

        if (result === false) {
          return;
        }
      }

      await onClose();
    } finally {
      setClosing(false);
    }
  }

  const drawer = (
    <aside
      className={[
        "admin-workbench-drawer",
        closing ? "is-closing" : "",
        className,
      ].filter(Boolean).join(" ")}
      style={{
        "--admin-workbench-drawer-width": cssWidth,
      }}
    >
      <div className="admin-workbench-drawer__header">
        <strong className="admin-workbench-drawer__title">
          {title}
        </strong>
      </div>

      {onClose ? (
        <div className="admin-workbench-drawer__close-row">
          <button
            type="button"
            className="admin-workbench-drawer__close-button"
            disabled={closing}
            onClick={requestClose}
          >
            {closing ? "Closing..." : closeLabel}
          </button>
          {actions}
        </div>
      ) : null}

      <div
        className={[
          "admin-workbench-drawer__body",
          padded ? "is-padded" : "",
        ].filter(Boolean).join(" ")}
      >
        {children}
      </div>

      {footer ? (
        <div className="admin-workbench-drawer__footer">
          {footer}
        </div>
      ) : null}
    </aside>
  );

  if (!portal) return drawer;

  return createPortal(
    <div
      ref={overlayRef}
      className="admin-workbench-drawer-host"
      style={{
        "--admin-workbench-drawer-width": cssWidth,
      }}
    >
      {drawer}
    </div>,
    document.body
  );
}

// Keep the public interface unchanged; desktop retains the original implementation.
export default function AdminWorkbenchDrawer(props) {
  const isMobile = useAdminMobile();
  return isMobile
    ? <MobileWorkbenchDrawer {...props} />
    : <DesktopWorkbenchDrawer {...props} />;
}
