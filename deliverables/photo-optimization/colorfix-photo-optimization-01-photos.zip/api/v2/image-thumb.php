<?php
declare(strict_types=1);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(200);
    exit;
}
require_once __DIR__ . '/../autoload.php';
require_once __DIR__ . '/../db.php';
\App\PHOTOS\Endpoints\PhotoThumbnailEndpoint::handle($pdo, dirname(__DIR__, 2));
