<?php
declare(strict_types=1);
namespace App\GALLERY\Endpoints;

use App\REX\Repos\PdoRexReservationRepository;
use App\Repos\PdoPaletteViewerRepository;
use App\GALLERY\Helpers\GalleryFilterHelper;
use PDO;

/**
 * Public Gallery query coordinator. Owns the legacy query path until all stored
 * Gallery SQL has migrated to vw_gallery; modern queries delegate to GalleryEndpoint.
 * Called by /api/v2/gallery/run-query.php; compatibility URLs redirect there.
 */
final class GalleryRunQueryEndpoint
{
    public static function handle(PDO $pdo, string $logFile): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'POST required']);
            return;
        }
        // ---- tiny helpers -----------------------------------------------------------

        // Log path is provided by the public doorbell; the department owns request behavior.

        $log = static function(string $msg) use ($logFile): void {

          @file_put_contents($logFile, '['.date('Y-m-d H:i:s')."] $msg\n", FILE_APPEND);

        };

        register_shutdown_function(static function () use ($log): void {

          $error = error_get_last();

          if (!$error) return;

          $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];

          if (!in_array($error['type'] ?? 0, $fatalTypes, true)) return;

          $log(

            'Fatal shutdown: '

            . ($error['message'] ?? 'unknown')

            . ' in ' . ($error['file'] ?? 'unknown')

            . ':' . ($error['line'] ?? 0)

          );

        });

        $extractNamedParamsFromQuery = static function(string $sql): array {

          preg_match_all('/:([a-zA-Z_][a-zA-Z0-9_]*)/', $sql, $m);

          return array_values(array_unique($m[1] ?? []));

        };

        $jexit = static function(int $code, array $payload): void {

          http_response_code($code);

          echo json_encode($payload, JSON_UNESCAPED_SLASHES);

          exit;

        };



        /**

         * Remove inner ORDER BY (best-effort) and hoist trailing LIMIT/OFFSET

         * so our outer ORDER BY is authoritative and paging happens after sorting.

         */

        $normalizeQueryForOuterOrder = static function(string $sql): array {

          $limit = '';

          // Capture and remove trailing LIMIT ... [OFFSET ...] or LIMIT x,y

          if (preg_match('/\sLIMIT\s+\d+(?:\s*,\s*\d+|\s+OFFSET\s+\d+)?\s*$/i', $sql, $m)) {

            $limit = $m[0];

            $sql   = preg_replace('/\sLIMIT\s+\d+(?:\s*,\s*\d+|\s+OFFSET\s+\d+)?\s*$/i', '', $sql);

          }

          // Remove any trailing ORDER BY ... (best effort; we control stored SQL)

          $sql = preg_replace('/\sORDER\s+BY\s+.+$/is', '', $sql);

          return [$sql, $limit];

        };



        // ---- body -------------------------------------------------------------------

        try {

          $rexRepo = new PdoRexReservationRepository($pdo);

          $paletteViewerRepo = new PdoPaletteViewerRepository($pdo);



          $raw  = file_get_contents('php://input') ?: '';

          $data = json_decode($raw, true);

          if (!is_array($data)) $data = [];



          $queryId = isset($data['query_id']) ? (int)$data['query_id'] : 0;

          if ($queryId <= 0) $jexit(400, ['error' => 'Missing or invalid query_id']);

          // The query's SQL source determines Gallery ownership.
          // Keep the two verified pilots enabled while their stored SQL transitions.
          // Other queries retain their legacy execution path until they use vw_gallery.
          $galleryRouteStmt = $pdo->prepare('SELECT `query` FROM sql_queries WHERE query_id = ?');
          $galleryRouteStmt->execute([$queryId]);
          $gallerySql = (string) ($galleryRouteStmt->fetchColumn() ?: '');
          $isGalleryQuery = in_array($queryId, [12, 15], true)
            || preg_match('/\b(?:FROM|JOIN)\s+`?vw_gallery`?\b/i', $gallerySql) === 1;
          if ($isGalleryQuery) {
            \App\GALLERY\Endpoints\GalleryEndpoint::handle($pdo);
            exit;
          }



          // 1) Fetch items for this query AND global inserts (17)

          $stmtItems = $pdo->prepare("

            SELECT *

              FROM items

             WHERE (query_id = :qid OR query_id = 17)

               AND is_active = 1

             ORDER BY

               CASE WHEN query_id = 17 THEN 1 ELSE 0 END,

               COALESCE(insert_position, 999999) ASC,

               id ASC

          ");

          $stmtItems->execute([':qid' => $queryId]);

          $itemResults = $stmtItems->fetchAll(PDO::FETCH_ASSOC);



          // 2) Fetch the stored SQL row

          $stmtQuery = $pdo->prepare("SELECT * FROM sql_queries WHERE query_id = ?");

          $stmtQuery->execute([$queryId]);

          $queryRow = $stmtQuery->fetch(PDO::FETCH_ASSOC);



          if (!$queryRow || ($queryRow['query'] ?? '') === '') {

            $jexit(404, ['error' => 'Query not found or missing SQL']);

          }



          // 3) Build final SQL (+ filters)

          $queryText = (string)$queryRow['query'];



          $searchFilters = is_array($data['searchFilters'] ?? null) ? $data['searchFilters'] : [];

          [$finalQuery, $namedFromFilters] = GalleryFilterHelper::apply($pdo, $searchFilters, $queryText);



          // Gather params BEFORE deciding group mode

          $paramsRaw = $data['params'] ?? [];

          $params    = is_array($paramsRaw) ? $paramsRaw : [];

          $params = $namedFromFilters + $params;



          if (!isset($params['group_mode'])) {

            $params['group_mode'] = 'hue'; // default

          }

          $groupMode = in_array($params['group_mode'], ['lightness', 'chroma'], true)

            ? $params['group_mode']

            : 'hue';



          // Are we dealing with swatches? (Only swatch queries have hcl_* / light_cat_*)

          $isSwatchQuery = (trim((string)($queryRow['item_type'] ?? '')) === 'swatch');



          // 4) If it's a swatch query, normalize and impose our outer ORDER BY.

          //    Otherwise, leave the stored SQL order alone.

          if ($isSwatchQuery) {

            [$innerSql, $innerLimit] = $normalizeQueryForOuterOrder($finalQuery);



            // Wrap the inner query; join cd for Lightness sort if view only exposes light_cat_id

            $finalQuery  = "SELECT q.*,"

                         . " cd.name AS __light_cat_name_outer,"

                         . " cd.sort_order AS __light_cat_order_outer"

                         . " FROM ( $innerSql ) AS q"

                         . " LEFT JOIN category_definitions cd"

                         . "   ON cd.id = q.light_cat_id AND cd.type = 'Lightness' ";



            if ($groupMode === 'lightness') {

              // Lightness mode: group by Light/Medium/Dark then graduate light → dark

              $finalQuery .= " ORDER BY"

                           . "  COALESCE(q.light_cat_order, __light_cat_order_outer, 999),"

                           . "  q.hcl_l DESC,"   // lightest → darkest inside the band

                           . "  q.hcl_c ASC,"    // softer first (tie-breaker)

                           . "  q.hcl_h ASC";    // final tie-breaker

            } else if ($groupMode === 'chroma') {

              // Chroma mode: most saturated to least, then hue sweep

              $finalQuery .= " ORDER BY q.hcl_c DESC, q.hcl_h ASC, q.hcl_l DESC";

            } else {

              // Hue mode (legacy)

              $finalQuery .= " ORDER BY q.hue_cat_order, q.hcl_h ASC, q.hcl_l DESC";

            }



            if ($innerLimit) $finalQuery .= " $innerLimit";

          }



          // 5) Execute

          $usedNames = $extractNamedParamsFromQuery($finalQuery);

          $binds = array_intersect_key($params, array_flip($usedNames));



          $log("Final query: $finalQuery | Params: " . json_encode($binds));



          $stmt = $pdo->prepare($finalQuery);

          foreach ($binds as $k => $v) {

            $stmt->bindValue(':'.$k, $v, PDO::PARAM_STR);

          }

          $stmt->execute();

          $queryResults = $stmt->fetchAll(PDO::FETCH_ASSOC);



          // 6.5) Optionally inject "picture swatch" items for swatch queries.

          $hasSwatchRows = false;

          if ($queryResults) {

            foreach ($queryResults as $row) {

              if (($row['item_type'] ?? '') === 'swatch' || ($row['item_type'] ?? '') === 'no-render') {

                $hasSwatchRows = true;

                break;

              }

              if (array_key_exists('hcl_l', $row) || array_key_exists('hex6', $row)) {

                $hasSwatchRows = true;

                break;

              }

              if (!empty($row['id']) && (isset($row['name']) || isset($row['code']))) {

                $hasSwatchRows = true;

                break;

              }

            }

          }

          if (($isSwatchQuery || $hasSwatchRows) && $queryResults) {

            $colorIds = [];

            foreach ($queryResults as $row) {

              $cid = isset($row['id']) ? (int)$row['id'] : (int)($row['color_id'] ?? 0);

              if ($cid > 0) $colorIds[$cid] = true;

            }



            $pictureByColor = [];

            $zoomByColor = [];

            if ($colorIds) {

              $placeholders = implode(',', array_fill(0, count($colorIds), '?'));





                $stmtSaved = $pdo->prepare("SELECT m.color_id, pl.photo_library_id, pl.rel_path, pl.source_type, pl.inspiration_photo_id,

                    pc.crop_x, pc.crop_y, pc.crop_width, pc.crop_height,

                    pa.artwork_id, pa.artist, pa.official_title, pa.display_title,

                    'zoom' AS photo_type, NULL AS trigger_color_id, pl.photo_library_id AS order_index,

                    sp.id AS saved_palette_id, NULL AS saved_palette_set_id, sp.palette_hash, sp.nickname, sp.brand

                    FROM photo_library pl LEFT JOIN photo_library inspiration ON inspiration.photo_library_id = pl.inspiration_photo_id AND inspiration.source_type = 'art'
                    JOIN saved_palettes sp ON sp.id = CASE WHEN pl.source_type = 'art_inspired' AND inspiration.photo_library_id IS NOT NULL THEN inspiration.palette_id ELSE pl.palette_id END

                    JOIN saved_palette_members m ON m.saved_palette_id = sp.id

                    LEFT JOIN photo_crops pc ON pc.photo_library_id = pl.photo_library_id AND pc.crop_type = 'swatch'

                    LEFT JOIN photos_artwork pa ON pa.photo_library_id = pl.photo_library_id

                    WHERE m.color_id IN ($placeholders) AND pl.show_in_gallery = 1

                      AND COALESCE(pl.is_inactive, 0) = 0 AND COALESCE(pl.is_retired, 0) = 0

                      AND pl.rel_path IS NOT NULL AND pl.rel_path <> ''

                    ORDER BY m.color_id, pl.photo_library_id");

                $photoParams = array_keys($colorIds);



              $stmtSaved->execute($photoParams);

              $savedRows = $stmtSaved->fetchAll(PDO::FETCH_ASSOC);



              $photoRows = $savedRows;



              $byColor = [];

              foreach ($photoRows as $row) {

                $cid = (int)$row['color_id'];

                if (!$cid) continue;

                if (!isset($byColor[$cid])) $byColor[$cid] = [];



                if (!empty($row['saved_palette_id'])) {

                  $pid = (int)$row['saved_palette_id'];

                  $paletteKey = "saved:{$pid}";

                  if (!isset($byColor[$cid][$paletteKey])) {

                    $byColor[$cid][$paletteKey] = [

                      'palette' => [

                        'kind' => 'saved',

                        'id' => $pid,

                        'hash' => $row['palette_hash'] ?? null,

                        'set_id' => isset($row['saved_palette_set_id']) ? (int)$row['saved_palette_set_id'] : null,

                        'nickname' => $row['nickname'] ?? null,

                        'brand' => $row['brand'] ?? null,

                      ],

                      'photos' => [],

                    ];

                  }

                  $byColor[$cid][$paletteKey]['photos'][] = [

                    'photo_id' => (int)$row['photo_library_id'],

                    'rel_path' => $row['rel_path'] ?? null,

                     'source_type' => $row['source_type'] ?? null,
                     'inspiration_photo_id' => $row['inspiration_photo_id'] ?? null,

                     'crop_x' => $row['crop_x'] ?? null,

                     'crop_y' => $row['crop_y'] ?? null,

                     'crop_width' => $row['crop_width'] ?? null,

                     'crop_height' => $row['crop_height'] ?? null,

                     'artwork_id' => $row['artwork_id'] ?? null,

                     'artist' => $row['artist'] ?? null,

                     'official_title' => $row['official_title'] ?? null,

                     'display_title' => $row['display_title'] ?? null,

                    'photo_type' => $row['photo_type'] ?? null,

                    'trigger_color_id' => isset($row['trigger_color_id']) ? (int)$row['trigger_color_id'] : null,

                    'saved_palette_set_id' => isset($row['saved_palette_set_id']) ? (int)$row['saved_palette_set_id'] : null,

                  ];

                  continue;

                }



              }



              foreach ($byColor as $cid => $palettes) {

                $exactPaletteIds = [];

                $fallbackPaletteIds = [];

                $zoomCandidates = [];

                foreach ($palettes as $pid => $entry) {

                  $hasExact = false;

                  $hasFallback = false;

                  foreach ($entry['photos'] as $photo) {

                    if (($photo['photo_type'] ?? '') === 'zoom') {

                      if (($photo['trigger_color_id'] ?? null) === $cid && !empty($photo['rel_path'])) {

                        $zoomCandidates[] = [

                          'palette' => $entry['palette'],

                          'photo' => $photo,

                        ];

                      }

                      continue;

                    }

                    if ($photo['trigger_color_id'] === $cid) {

                      $hasExact = true;

                    } else if ($photo['trigger_color_id'] === null) {

                      $hasFallback = true;

                    }

                  }

                  if ($hasExact) {

                    $exactPaletteIds[] = $pid;

                  } else if ($hasFallback) {

                    $fallbackPaletteIds[] = $pid;

                  }

                }



                $paletteIds = $exactPaletteIds ?: $fallbackPaletteIds;

                if (!$paletteIds) {

                  if ($zoomCandidates) {

                    $zoomByColor[$cid] = $zoomCandidates[random_int(0, count($zoomCandidates) - 1)];

                  }

                  continue;

                }

                $randPaletteId = $paletteIds[random_int(0, count($paletteIds) - 1)];

                $palette = $palettes[$randPaletteId]['palette'];

                $photos = $palettes[$randPaletteId]['photos'];

                if (!$photos) continue;

                $photos = array_values(array_filter($photos, function($photo) use ($cid, $exactPaletteIds) {

                  if (($photo['photo_type'] ?? '') === 'zoom') return false;

                  if ($photo['trigger_color_id'] === $cid) return true;

                  if ($photo['trigger_color_id'] === null && empty($exactPaletteIds)) return true;

                  return false;

                }));

                if (!$photos) continue;

                $photo = $photos[random_int(0, count($photos) - 1)];

                $pictureByColor[$cid] = [

                  'palette' => $palette,

                  'photo' => $photo,

                ];

                if ($zoomCandidates) {

                  $zoomByColor[$cid] = $zoomCandidates[random_int(0, count($zoomCandidates) - 1)];

                }

              }

            }



            // Resolve each saved palette to its active public Palette Viewer,

            // then resolve that Palette Viewer to its canonical active REX reservation.

            // Important: REX palette_viewer resource_id is palette_viewers.palette_viewer_id,

            // not saved_palette_set_id and not saved_palette_viewer_content_id.

            $savedPaletteIdsForViewerRex = [];

            foreach ($pictureByColor as $entry) {

              $savedPaletteId = (int)($entry['palette']['id'] ?? 0);

              if ($savedPaletteId > 0) {

                $savedPaletteIdsForViewerRex[$savedPaletteId] = true;

              }

            }

            foreach ($zoomByColor as $entry) {

              $savedPaletteId = (int)($entry['palette']['id'] ?? 0);

              if ($savedPaletteId > 0) {

                $savedPaletteIdsForViewerRex[$savedPaletteId] = true;

              }

            }



            $viewerRexUrlBySavedPaletteId = [];

            if ($savedPaletteIdsForViewerRex) {

              $publicViewersBySavedPaletteId = $paletteViewerRepo->findActivePublicBySavedPaletteIds(

                array_keys($savedPaletteIdsForViewerRex)

              );



              $paletteViewerIdBySavedPaletteId = [];

              $paletteViewerIds = [];



              foreach ($publicViewersBySavedPaletteId as $savedPaletteId => $viewers) {

                $viewer = $viewers[0] ?? null;

                if ($viewer === null) {

                  continue;

                }



                $paletteViewerId = (int)$viewer->paletteViewerId;

                if ($paletteViewerId <= 0) {

                  continue;

                }



                $paletteViewerIdBySavedPaletteId[(int)$savedPaletteId] = $paletteViewerId;

                $paletteViewerIds[$paletteViewerId] = true;

              }



              if ($paletteViewerIds) {

                $rexByPaletteViewerId = $rexRepo->findActiveByResourceIds(

                  'viewer',

                  'palette_viewer',

                  array_keys($paletteViewerIds)

                );



                foreach ($paletteViewerIdBySavedPaletteId as $savedPaletteId => $paletteViewerId) {

                  $reservations = $rexByPaletteViewerId[$paletteViewerId] ?? [];

                  $reservation = $reservations[0] ?? null;

                  if ($reservation !== null) {

                    $viewerRexUrlBySavedPaletteId[$savedPaletteId] = '/t/' . $reservation->token;

                  }

                }

              }

            }



            if ($pictureByColor || $zoomByColor) {

              $withPictures = [];

              $usedPhotoKeys = [];

              $usedZoomKeys = [];

              foreach ($queryResults as $row) {

                $withPictures[] = $row;

                $cid = isset($row['id']) ? (int)$row['id'] : (int)($row['color_id'] ?? 0);

                if (!$cid || (empty($pictureByColor[$cid]) && empty($zoomByColor[$cid]))) continue;

                if (!empty($pictureByColor[$cid])) {

                  $pic = $pictureByColor[$cid];

                  $palette = $pic['palette'];

                  $photo = $pic['photo'];

                  if (!empty($photo['rel_path'])) {

                    $photoKey = (string)($photo['photo_id'] ?? $photo['id'] ?? $photo['rel_path']);

                    if ($photoKey !== '' && isset($usedPhotoKeys[$photoKey])) {

                      // already placed this full photo in the results

                    } else {

                      if ($photoKey !== '') $usedPhotoKeys[$photoKey] = true;

                      $withPictures[] = [

                        'id' => 'ps_' . $cid . '_' . ($photo['photo_id'] ?? uniqid()),

                        'item_type' => (($photo['source_type'] ?? '') === 'art' ? 'art-swatch' : 'picture-swatch'),

                         'artwork_id' => $photo['artwork_id'] === null ? null : (int)$photo['artwork_id'],

                         'artist' => $photo['artist'] ?? null,

                         'official_title' => $photo['official_title'] ?? null,

                         'display_title' => $photo['display_title'] ?? null,

                         'crop_x' => $photo['crop_x'] === null ? null : (float)$photo['crop_x'],

                         'crop_y' => $photo['crop_y'] === null ? null : (float)$photo['crop_y'],

                         'crop_width' => $photo['crop_width'] === null ? null : (float)$photo['crop_width'],

                         'crop_height' => $photo['crop_height'] === null ? null : (float)$photo['crop_height'],

                        'photo_library_id' => (int)($photo['photo_id'] ?? 0),
                        'source_type' => $photo['source_type'] ?? null,
                        'inspiration_photo_id' => $photo['inspiration_photo_id'] ?? null,

                        'photo_url' => $photo['rel_path'],

                        'photo_type' => $photo['photo_type'] ?? null,

                        'palette_id' => $palette['id'] ?? null,

                        'saved_palette_id' => ($palette['kind'] ?? '') === 'saved' ? ($palette['id'] ?? null) : null,

                        'palette_hash' => $palette['hash'] ?? null,

                        'saved_palette_set_id' => $palette['set_id'] ?? ($photo['saved_palette_set_id'] ?? null),

                        'rex_url' => $viewerRexUrlBySavedPaletteId[(int)($palette['id'] ?? 0)] ?? null,

                        'palette_name' => $palette['nickname'] ?? null,

                        'palette_brand' => $palette['brand'] ?? null,

                        'source_color_id' => $cid,

                        'hue_cats' => $row['hue_cats'] ?? null,

                        'light_cat_name' => $row['light_cat_name'] ?? ($row['__light_cat_name_outer'] ?? null),

                        'light_cat_order' => $row['light_cat_order'] ?? ($row['__light_cat_order_outer'] ?? null),

                        'hcl_h' => $row['hcl_h'] ?? null,

                        'hcl_c' => $row['hcl_c'] ?? null,

                        'hcl_l' => $row['hcl_l'] ?? null,

                      ];

                    }

                  }

                }

                if (!empty($zoomByColor[$cid])) {

                  $zoom = $zoomByColor[$cid];

                  $zpalette = $zoom['palette'];

                  $zphoto = $zoom['photo'];

                  if (!empty($zphoto['rel_path'])) {

                    $zoomKey = (string)($zphoto['photo_id'] ?? $zphoto['id'] ?? $zphoto['rel_path']);

                    if ($zoomKey === '' || empty($usedZoomKeys[$zoomKey])) {

                      if ($zoomKey !== '') $usedZoomKeys[$zoomKey] = true;

                      $withPictures[] = [

                        'id' => 'psz_' . $cid . '_' . ($zphoto['photo_id'] ?? uniqid()),

                        'item_type' => (($zphoto['source_type'] ?? '') === 'art' ? 'art-swatch' : 'picture-swatch'),

                         'artwork_id' => $zphoto['artwork_id'] === null ? null : (int)$zphoto['artwork_id'],

                         'artist' => $zphoto['artist'] ?? null,

                         'official_title' => $zphoto['official_title'] ?? null,

                         'display_title' => $zphoto['display_title'] ?? null,

                         'crop_x' => $zphoto['crop_x'] === null ? null : (float)$zphoto['crop_x'],

                         'crop_y' => $zphoto['crop_y'] === null ? null : (float)$zphoto['crop_y'],

                         'crop_width' => $zphoto['crop_width'] === null ? null : (float)$zphoto['crop_width'],

                         'crop_height' => $zphoto['crop_height'] === null ? null : (float)$zphoto['crop_height'],

                        'photo_library_id' => (int)($zphoto['photo_id'] ?? 0),
                        'source_type' => $zphoto['source_type'] ?? null,
                        'inspiration_photo_id' => $zphoto['inspiration_photo_id'] ?? null,

                        'photo_url' => $zphoto['rel_path'],

                        'photo_type' => $zphoto['photo_type'] ?? null,

                        'palette_id' => $zpalette['id'] ?? null,

                        'saved_palette_id' => ($zpalette['kind'] ?? '') === 'saved' ? ($zpalette['id'] ?? null) : null,

                        'palette_hash' => $zpalette['hash'] ?? null,

                        'saved_palette_set_id' => $zpalette['set_id'] ?? ($zphoto['saved_palette_set_id'] ?? null),

                        'rex_url' => $viewerRexUrlBySavedPaletteId[(int)($zpalette['id'] ?? 0)] ?? null,

                        'palette_name' => $zpalette['nickname'] ?? null,

                        'palette_brand' => $zpalette['brand'] ?? null,

                        'source_color_id' => $cid,

                        'hue_cats' => $row['hue_cats'] ?? null,

                        'light_cat_name' => $row['light_cat_name'] ?? ($row['__light_cat_name_outer'] ?? null),

                        'light_cat_order' => $row['light_cat_order'] ?? ($row['__light_cat_order_outer'] ?? null),

                        'hcl_h' => $row['hcl_h'] ?? null,

                        'hcl_c' => $row['hcl_c'] ?? null,

                        'hcl_l' => $row['hcl_l'] ?? null,

                      ];

                    }

                  }

                }

              }

              $queryResults = $withPictures;

            }

          }



          // 6) Safety: default item_type if missing

          foreach ($queryResults as &$r) { if (!isset($r['item_type'])) $r['item_type'] = 'unknown'; }

          foreach ($itemResults as &$i)  { if (!isset($i['item_type'])) $i['item_type'] = 'unknown'; }



          // 7) Response

          $jexit(200, [

            'success' => true,

            'meta' => [

              'meta_id'        => $queryRow['query_id'],

              'display'        => $queryRow['display'] ?? ($queryRow['name'] ?? ''),

              'description'    => $queryRow['description'] ?? '',

              'item_type'      => $queryRow['item_type'] ?? '',

              'type'           => $queryRow['type'] ?? '',

              'on_click_query' => $queryRow['on_click_query'] ?? '',

              'has_header'     => $queryRow['has_header'] ?? '',

              'header_title'   => $queryRow['header_title'] ?? '',

              'header_subtitle'=> $queryRow['header_subtitle'] ?? '',

              'header_content' => $queryRow['header_content'] ?? '',

              'params'         => $params, // includes group_mode

            ],

            'results'     => $queryResults,

            'inserts'     => $itemResults,

            'rowCount'    => count($queryResults),

            'insertCount' => count($itemResults),

          ]);



        } catch (\PDOException $e) {

          $log('SQL error: '.$e->getMessage());

          $jexit(500, ['error' => 'Database error']);

        } catch (\Throwable $e) {

          $log('General error: '.$e->getMessage());

          $jexit(500, ['error' => 'Unexpected error']);

        }
    }
}
