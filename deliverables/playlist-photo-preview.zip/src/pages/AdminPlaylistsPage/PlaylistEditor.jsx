import PhotoPreview from "@components/PhotoPreview";
import { photoImageProps } from "@helpers/imageThumb";
import { resolvePhotoPalette } from "./photoPalette";
import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";
import { closestCenter, DndContext, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import PlaylistSlideDragRow, { PlaylistSlideDragHandle } from "./PlaylistSlideDragRow";

import {
  useNavigate,
} from "react-router-dom";

import {
  useAppState,
} from "@context/AppStateContext.jsx";

import {
  AdminBadge,
  AdminButton,
  AdminDetailPane,
  AdminEditor,
  AdminEmptyState,
  AdminField,
  AdminMetaText,
  AdminNotice,
  AdminSmartGrid,
  AdminStack,
  AdminToolbar,
  useAdminDialog,
} from "@components/AdminLayout";

import PhotoPickerDialog from "@components/Dialogs/PhotoPickerDialog";
import ColorPlanPickerModal from "@components/ColorPlanPickerModal";
import PlaylistRexButton from "@components/REX/PlaylistRexButton";
import useAdminMobile from "@components/AdminLayout/useAdminMobile";
import MobileSelect from "@components/AdminLayout/mobile/MobileSelect";

import {
  API_FOLDER,
} from "@helpers/config";

import {
  makePhotoRef,
  parsePhotoRef,
} from "@helpers/assetImage";

import PlaylistRecordEditor from "./PlaylistRecordEditor";
import SlideDefaultsDialog from "./SlideDefaultsDialog";
import PlaylistSlideEditor, {
  BRAND_BUMPER_BODY_TEMPLATE,
  HUE_WHEEL_BODY_TEMPLATE,
} from "./PlaylistSlideEditor";
import { slideTypeLabel } from "./slideTypes";


const LIST_URL =
  `${API_FOLDER}/v2/admin/playlists/list.php`;

const PROJECTS_LIST_URL =
  `${API_FOLDER}/v2/admin/projects/list.php`;

const GET_URL =
  `${API_FOLDER}/v2/admin/playlists/get.php`;

const SAVE_URL =
  `${API_FOLDER}/v2/admin/playlists/save.php`;

const SAVE_ITEMS_URL =
  `${API_FOLDER}/v2/admin/playlist-items/save.php`;

const DELETE_URL =
  `${API_FOLDER}/v2/admin/playlists/delete.php`;

const REX_PLAYLIST_URL =
  `${API_FOLDER}/v2/admin/rex/playlist-url.php`;

const SAVED_LIST_URL =
  `${API_FOLDER}/v2/admin/saved-palettes.php`;

const PHOTO_LIBRARY_LIST_URL =
  `${API_FOLDER}/v2/admin/photo-library/list.php`;

const SLIDE_PRESETS_LIST_URL =
  `${API_FOLDER}/v2/admin/playlist-slide-presets/list.php`;

const PERMISSION_STATUS_EVENT =
  "colorfix:photo-permission-status";

const SLIDE_CLIPBOARD_KEY =
  "colorfix:playlist-slide-clipboard";

const EMPTY_COPIED_SLIDES = [];


const DEFAULT_PLAYLIST_TYPES = [
  "normal",
  "teaching",
];

const ANALYZER_ROLES = [
  "ignore",
  "before",
  "after",
  "single",
  "teaser",
];

const FINDER_START_VALUES = [
  "auto",
  "this",
  "previous",
];


const emptyPlaylist = {
  playlist_id: null,
  project_id: "",
  title: "",
  type: "normal",
  is_active: true,
  is_public: false,
  slug: "",
  headline: "",
  page_title: "",
  meta_description: "",
  dek: "",
  intro_html: "",
  body_html: "",
  hero_image_id: "",
  hero_image_url: "",
  hero_alt: "",
  indexable: true,
  published_at: "",
};


const emptyItem = {
  _clientKey: "",
  playlist_item_id: null,

  palette_hash: "",
  image_url: "",
  photo_library_id: "",

  title: "",
  subtitle: "",
  subtitle_2: "",
  body: "",
  item_type: "non-palette",
  layout: "default",
  title_mode: "",
  star: true,
  transition: "",
  duration_ms: "",
  exclude_from_thumbs: false,
  is_share_image: false,
  site: true,
  yt: true,
  concept: true,
  showcase: true,
  client: true,
  pin: true,
  color_plan_id: "",
  version_number: 1,
  is_final: false,
  analyzer_role: "ignore",
  finder_start: "auto",
  is_active: true,
};


const PlaylistEditor = forwardRef(function PlaylistEditor(
  {
    playlistId,
    initialProjectId = null,
    initialCopiedSlides = EMPTY_COPIED_SLIDES,
    onSaved = null,
    onDeleted = null,
    onNew = null,
    onJumpPlaylistId = null,
  },
  ref
) {
  const isMobile = useAdminMobile();
  const detailRequestRef = useRef(0);
  const detailAbortRef = useRef(null);

  useEffect(() => () => {
    detailRequestRef.current++;
    detailAbortRef.current?.abort();
  }, []);

  const dialog =
    useAdminDialog();

  const navigate =
    useNavigate();

  const {
    playerExperience,
    setPlayerExperience,
  } = useAppState();

  const routePlaylistId =
    /^\d+$/.test(
      String(
        playlistId ||
        ""
      )
    )
      ? Number(
          playlistId
        )
      : null;

  const [previewPhoto, setPreviewPhoto] = useState(null);

  const isNewRoute =
    routePlaylistId === null;


  const [
    query,
    setQuery,
  ] = useState("");

  const [
    sortMode,
    setSortMode,
  ] = useState("title");

  const [
    playlists,
    setPlaylists,
  ] = useState([]);


  const [
    projects,
    setProjects,
  ] = useState([]);

  const [
    listLoading,
    setListLoading,
  ] = useState(false);

  const [
    listError,
    setListError,
  ] = useState("");


  const [
    playlist,
    setPlaylist,
  ] = useState(emptyPlaylist);

  const [
    items,
    setItems,
  ] = useState([]);

  const [
    detailLoading,
    setDetailLoading,
  ] = useState(false);

  const [
    detailError,
    setDetailError,
  ] = useState("");

  const [
    dirty,
    setDirty,
  ] = useState(false);

  const [
    saving,
    setSaving,
  ] = useState(false);

  const [
    deleting,
    setDeleting,
  ] = useState(false);

  const [
    saveMessage,
    setSaveMessage,
  ] = useState("");


  const [
    playlistTypes,
    setPlaylistTypes,
  ] = useState(
    DEFAULT_PLAYLIST_TYPES
  );

  const [
    savedOptions,
    setSavedOptions,
  ] = useState([]);

  const [
    selectedSlideKey,
    setSelectedSlideKey,
  ] = useState(null);

  const [
    batchSelectedKeys,
    setBatchSelectedKeys,
  ] = useState([]);

  const [
    slideClipboardCount,
    setSlideClipboardCount,
  ] = useState(
    () =>
      readSlideClipboard()
        .length
  );

  const [
    playlistEditorOpen,
    setPlaylistEditorOpen,
  ] = useState(false);

  const [
    playlistDraft,
    setPlaylistDraft,
  ] = useState(emptyPlaylist);


  const [
    slidePresets,
    setSlidePresets,
  ] = useState([]);

  const insertionPresets = useMemo(() => slidePresets
    .filter((preset) => preset?.is_enabled !== false)
    .flatMap((preset) => {
      // Two UI choices reuse the existing Slide defaults; stored preset rows stay unchanged.
      if (preset.preset_key === "normal") {
        return ["palette", "non-palette"].map((type) => ({
          ...preset,
          option_key: `${preset.preset_key}:${type}`,
          item_type: type,
          label: slideTypeLabel(type),
        }));
      }
      return [{
        ...preset,
        option_key: preset.preset_key,
        label: ["intro", "text", "hue-wheel", "cover-image", "brand-bumper"].includes(preset.preset_key)
          ? slideTypeLabel(preset.item_type)
          : preset.label || preset.preset_key,
      }];
    }), [slidePresets]);

  const [
    slidePresetsLoading,
    setSlidePresetsLoading,
  ] = useState(false);

  const [
    slidePresetsError,
    setSlidePresetsError,
  ] = useState("");

  const [
    slideDefaultsOpen,
    setSlideDefaultsOpen,
  ] = useState(false);

  const [
    photoPickerKey,
    setPhotoPickerKey,
  ] = useState(null);

  const [
    heroPickerOpen,
    setHeroPickerOpen,
  ] = useState(false);

  const [
    colorPlanPickerKey,
    setColorPlanPickerKey,
  ] = useState(null);


  const [
    photoThumbs,
    setPhotoThumbs,
  ] = useState({});

  const [
    photoInfo,
    setPhotoInfo,
  ] = useState({});


  const makeClientItemKey =
    useCallback(
      () =>
        `pli-${Date.now()}-${Math.random()
          .toString(36)
          .slice(2, 10)}`,
      []
    );


  const fetchPlaylists =
    useCallback(
      async (
        forceReload = false
      ) => {
        setListLoading(
          true
        );

        setListError(
          ""
        );

        try {
          const res =
            await fetch(
              LIST_URL,
              {
                credentials:
                  "include",

                cache:
                  forceReload
                    ? "reload"
                    : "default",
              }
            );

          const data =
            await res.json();

          if (
            !res.ok
            ||
            !data?.ok
          ) {
            throw new Error(
              data?.error ||
              "Failed to load playlists."
            );
          }

          setPlaylists(
            Array.isArray(
              data.items
            )
              ? data.items
              : []
          );

        } catch (err) {
          setListError(
            err?.message ||
            "Failed to load playlists."
          );

        } finally {
          setListLoading(
            false
          );
        }
      },
      []
    );


  const fetchProjects =
    useCallback(
      async () => {
        try {
          const res =
            await fetch(
              `${PROJECTS_LIST_URL}?_=${Date.now()}`,
              {
                credentials:
                  "include",
              }
            );

          const data =
            await res.json();

          if (
            !res.ok
            ||
            data?.ok === false
          ) {
            return;
          }

          const rows =
            Array.isArray(
              data?.projects
            )
              ? data.projects
              : Array.isArray(
                  data?.items
                )
                ? data.items
                : Array.isArray(
                    data?.rows
                  )
                  ? data.rows
                  : [];

          setProjects(
            [...rows].sort(
              (a, b) =>
                String(
                  a?.project_name ||
                  a?.name ||
                  ""
                ).localeCompare(
                  String(
                    b?.project_name ||
                    b?.name ||
                    ""
                  ),
                  undefined,
                  {
                    sensitivity:
                      "base",
                  }
                )
            )
          );
        } catch {
          // Project assignment is optional convenience data.
        }
      },
      []
    );


  const fetchPlaylist =
    useCallback(
      async (
        id,
        preserveSelection = null,
        showLoading = true
      ) => {
        if (!id) {
          return;
        }

        const requestId = ++detailRequestRef.current;
        detailAbortRef.current?.abort();
        const controller = new AbortController();
        detailAbortRef.current = controller;
        const timeout = window.setTimeout(() => controller.abort(), 30000);

        if (showLoading) {
          setDetailLoading(true);
        }

        setDetailError(
          ""
        );

        try {
          const res =
            await fetch(
              `${GET_URL}?playlist_id=${encodeURIComponent(String(id))}&_=${Date.now()}`,
              {
                signal: controller.signal,
                credentials:
                  "include",
              }
            );

          const data =
            await res.json();

          if (requestId !== detailRequestRef.current) return false;

          if (
            !res.ok
            ||
            !data?.ok
          ) {
            throw new Error(
              data?.error ||
              "Failed to load playlist."
            );
          }

          setPlaylist(
            normalizePlaylist(
              data.playlist
            )
          );

          const normalizedItems =
            (
              Array.isArray(
                data.items
              )
                ? data.items
                : []
            ).map(
              (item) =>
                normalizePlaylistItem(
                  item,
                  makeClientItemKey
                )
            );

          setItems(
            normalizedItems
          );

          let nextSelectedSlideKey =
            null;

          if (
            preserveSelection
          ) {
            const preservedId =
              Number(
                preserveSelection
                  ?.playlist_item_id ||
                0
              );

            const preservedIndex =
              Number(
                preserveSelection
                  ?.index
              );

            const preservedItem =
              (
                preservedId
                  ? normalizedItems.find(
                      (item) =>
                        Number(
                          item
                            ?.playlist_item_id ||
                          0
                        ) ===
                        preservedId
                    )
                  : null
              )
              ||
              (
                Number.isInteger(
                  preservedIndex
                )
                &&
                preservedIndex >=
                  0
                &&
                preservedIndex <
                  normalizedItems.length
                  ? normalizedItems[
                      preservedIndex
                    ]
                  : null
              );

            nextSelectedSlideKey =
              preservedItem
                ?._clientKey
              ||
              null;
          }

          setSelectedSlideKey(
            nextSelectedSlideKey
          );

          setBatchSelectedKeys([]);

          setDirty(
            false
          );

          return true;

        } catch (err) {
          if (requestId !== detailRequestRef.current) return false;
          setDetailError(
            (err?.name === 'AbortError' ? 'Loading the playlist timed out. Please try again.' : err?.message) ||
            "Failed to load playlist."
          );

          return false;

        } finally {
          window.clearTimeout(timeout);
          if (requestId === detailRequestRef.current) {
            setDetailLoading(false);
          }
        }
      },
      [
        makeClientItemKey,
      ]
    );


  const fetchSlidePresets =
    useCallback(
      async () => {
        setSlidePresetsLoading(
          true
        );

        setSlidePresetsError(
          ""
        );

        try {
          const res =
            await fetch(
              `${SLIDE_PRESETS_LIST_URL}?_=${Date.now()}`,
              {
                credentials:
                  "include",
              }
            );

          const data =
            await res.json();

          if (
            !res.ok
            ||
            !data?.ok
          ) {
            throw new Error(
              data?.error ||
              "Failed to load slide defaults."
            );
          }

          setSlidePresets(
            Array.isArray(
              data.presets
            )
              ? data.presets
              : []
          );

        } catch (err) {
          setSlidePresetsError(
            err?.message ||
            "Failed to load slide defaults."
          );

        } finally {
          setSlidePresetsLoading(
            false
          );
        }
      },
      []
    );


  async function fetchPlaylistTypes() {
    try {
      const params =
        new URLSearchParams({
          limit:
            "500",
          _:
            String(
              Date.now()
            ),
        });

      const res =
        await fetch(
          `${LIST_URL}?${params.toString()}`,
          {
            credentials:
              "include",
          }
        );

      const data =
        await res.json();

      if (
        !res.ok
        ||
        !data?.ok
      ) {
        return;
      }

      const types =
        Array.from(
          new Set(
            [
              ...DEFAULT_PLAYLIST_TYPES,

              ...(
                data.items ||
                []
              )
                .map(
                  (row) =>
                    String(
                      row
                        ?.type ||
                      ""
                    ).trim()
                )
                .filter(
                  Boolean
                ),
            ]
          )
        )
          .sort(
            (
              a,
              b
            ) =>
              a.localeCompare(
                b
              )
          );

      setPlaylistTypes(
        types
      );

    } catch {
      // Optional convenience list.
    }
  }


  async function fetchSavedPalettes() {
    try {
      const params =
        new URLSearchParams({
          limit:
            "500",
          _:
            String(
              Date.now()
            ),
        });

      const res =
        await fetch(
          `${SAVED_LIST_URL}?${params.toString()}`,
          {
            credentials:
              "include",
          }
        );

      const data =
        await res.json();

      if (
        !res.ok
        ||
        !data?.ok
      ) {
        return;
      }

      const options =
        (
          data.items ||
          []
        )
          .filter(
            (row) =>
              row
                .palette_hash
          )
          .reduce(
            (
              result,
              row
            ) => {
              const hash =
                String(
                  row
                    .palette_hash ||
                  ""
                ).trim();

              if (
                !hash
                ||
                result.some(
                  (item) =>
                    item
                      .palette_hash ===
                    hash
                )
              ) {
                return result;
              }

              result.push({
                ...row,

                id:
                  row.id,

                saved_palette_id:
                  row.saved_palette_id
                  ??
                  row.id,

                project_id:
                  row.project_id
                  ??
                  "",

                palette_hash:
                  hash,

                label:
                  String(
                    row.display_title ||
                    row.nickname ||
                    ""
                  ).trim()
                  ||
                  `Saved #${row.id}`,
              });

              return result;
            },
            []
          );

      setSavedOptions(
        options
      );

    } catch {
      // Optional convenience list.
    }
  }


  useEffect(() => {
    fetchPlaylistTypes();
    fetchSavedPalettes();
    fetchSlidePresets();
    fetchProjects();
  }, [
    fetchSlidePresets,
    fetchProjects,
  ]);


  useEffect(() => {
    if (
      isNewRoute
    ) {
      detailRequestRef.current++;
      detailAbortRef.current?.abort();
      setDetailLoading(false);
      const newPlaylist =
        {
          ...emptyPlaylist,

          project_id:
            Number(
              initialProjectId ||
              0
            ) > 0
              ? String(
                  initialProjectId
                )
              : "",
        };

      setPlaylist({
        ...newPlaylist,
      });

      const copiedSlides =
        Array.isArray(
          initialCopiedSlides
        )
          ? initialCopiedSlides
          : [];

      setItems(
        copiedSlides.map(
          (item) =>
            clonePlaylistItemForNewPlaylist(
              item,
              makeClientItemKey()
            )
        )
      );

      setBatchSelectedKeys([]);

      setSelectedSlideKey(
        null
      );

      setDetailError(
        ""
      );

      setSaveMessage(
        ""
      );

      setDirty(
        false
      );

      setPlaylistDraft({
        ...newPlaylist,
      });

      setPlaylistEditorOpen(
        true
      );

      return;
    }

    if (
      routePlaylistId
    ) {
      // Never expose the previous playlist's editing state under a new URL.
      setPlaylist({ ...emptyPlaylist });
      setItems([]);
      setSelectedSlideKey(null);
      setBatchSelectedKeys([]);
      setDirty(false);
      setSaveMessage(
        ""
      );

      fetchPlaylist(
        routePlaylistId
      );

    }
  }, [
    isNewRoute,
    routePlaylistId,
    fetchPlaylist,
    initialCopiedSlides,
    initialProjectId,
    makeClientItemKey,
  ]);


  const visiblePlaylists =
    useMemo(
      () => {
        const needle =
          query
            .trim()
            .toLowerCase();

        const rows =
          needle? playlists.filter(
                (row) => {
                  const title =
                    String(
                      row?.title ||
                      ""
                    )
                      .toLowerCase();

                  const id =
                    String(
                      row
                        ?.playlist_id ||
                      ""
                    );

                  return (
                    title.includes(
                      needle
                    )
                    ||
                    id.includes(
                      needle
                    )
                  );
                }
              )
            : [
                ...playlists,
              ];

        rows.sort(
          (
            a,
            b
          ) => {
            if (
              sortMode ===
              "id"
            ) {
              return (
                Number(
                  b?.playlist_id ||
                  0
                )
                -
                Number(
                  a?.playlist_id ||
                  0
                )
              );
            }

            const byTitle =
              String(
                a?.title ||
                ""
              ).localeCompare(
                String(
                  b?.title ||
                  ""
                ),
                undefined,
                {
                  numeric: true,
                  sensitivity:
                    "base",
                }
              );

            if (
              byTitle !== 0
            ) {
              return byTitle;
            }

            return (
              Number(
                a?.playlist_id ||
                0
              )
              -
              Number(
                b?.playlist_id ||
                0
              )
            );
          }
        );

        return rows;
      },
      [
        playlists,
        query,
        sortMode,
      ]
    );




  useEffect(() => {
    const missingIds =
      Array.from(
        new Set(
          items
            .map(
              (item) => {
                const photoId =
                  String(
                    getPhotoLibraryId(
                      item
                    ) ||
                    ""
                  ).trim();

                if (
                  !photoId
                  ||
                  photoThumbs[
                    photoId
                  ]
                ) {
                  return "";
                }

                return photoId;
              }
            )
            .filter(
              Boolean
            )
        )
      );

    if (
      missingIds.length ===
      0
    ) {
      return;
    }

    let cancelled =
      false;

    (
      async () => {
        try {
          const params =
            new URLSearchParams();

          params.set(
            "photo_library_ids",
            missingIds.join(
              ","
            )
          );

          params.set(
            "limit",
            String(
              Math.max(
                missingIds.length,
                1
              )
            )
          );

          params.set(
            "_",
            Date.now().toString()
          );

          const res =
            await fetch(
              `${PHOTO_LIBRARY_LIST_URL}?${params.toString()}`,
              {
                credentials:
                  "include",
              }
            );

          const data =
            await res.json();

          if (
            !res.ok
            ||
            !data?.ok
            ||
            cancelled
          ) {
            return;
          }

          setPhotoThumbs(
            (current) => {
              const next = {
                ...current,
              };

              for (
                const row
                of data.items || []
              ) {
                const id =
                  String(
                    row
                      ?.photo_library_id ||
                    ""
                  ).trim();

                if (!id) {
                  continue;
                }

                const imageUrl =
                  String(
                    row
                      ?.image_url
                    ||
                    row
                      ?.rel_path
                    ||
                    ""
                  ).trim();

                if (
                  imageUrl
                ) {
                  next[id] =
                    imageUrl;
                }
              }

              return next;
            }
          );

          setPhotoInfo(
            (current) => {
              const next = {
                ...current,
              };

              for (
                const row
                of data.items || []
              ) {
                const id =
                  String(
                    row
                      ?.photo_library_id ||
                    ""
                  ).trim();

                if (!id) {
                  continue;
                }

                next[id] =
                  photoInfoFromRow(
                    row
                  );
              }

              return next;
            }
          );

        } catch {
          // Photo metadata is convenience data.
        }
      }
    )();

    return () => {
      cancelled =
        true;
    };
  }, [
    items,
    photoThumbs,
  ]);


  useEffect(() => {
    function onPermissionChange(
      event
    ) {
      const detail =
        event?.detail || {};

      const photoId =
        String(
          detail.photo_library_id ||
          ""
        ).trim();

      if (!photoId) {
        return;
      }

      const nextStatus =
        detail
          .permission
          ?.photo_permission_status
        ||
        detail
          .photo_permission_status
        ||
        "unknown";

      setPhotoInfo(
        (current) => {
          if (
            !current[
              photoId
            ]
          ) {
            return current;
          }

          return {
            ...current,

            [photoId]: {
              ...current[
                photoId
              ],

              photoPermissionStatus:
                nextStatus,
            },
          };
        }
      );
    }

    window.addEventListener(
      PERMISSION_STATUS_EVENT,
      onPermissionChange
    );

    return () =>
      window.removeEventListener(
        PERMISSION_STATUS_EVENT,
        onPermissionChange
      );
  }, []);


  const resolvedShareItemKey =
    useMemo(
      () => {
        const explicit =
          items.find(
            (item) =>
              Boolean(
                item
                  ?.is_share_image
              )
              &&
              hasItemPhoto(
                item
              )
          );

        if (
          explicit
        ) {
          return explicit
            ._clientKey;
        }

        const first =
          items.find(
            hasItemPhoto
          );

        return first
          ? first._clientKey
          : null;
      },
      [
        items,
      ]
    );


  function markDirty() {
    setDirty(
      true
    );

    setSaveMessage(
      ""
    );

    setDetailError(
      ""
    );
  }


  async function navigateToPlaylist(
    row
  ) {
    const id =
      Number(
        row
          ?.playlist_id ||
        0
      );

    if (!id) {
      return;
    }

    const currentId =
      Number(
        playlist
          ?.playlist_id ||
        0
      );

    if (
      id ===
      currentId
    ) {
      return;
    }

    navigate(
      `/admin/playlists/${id}`
    );
  }


  async function beginNewPlaylist() {
    if (
      typeof onNew ===
      "function"
    ) {
      await onNew();
      return;
    }

    navigate(
      "/admin/playlists/new"
    );
  }


  function openPlaylistEditor() {
    setPlaylistDraft({
      ...playlist,
    });

    setPlaylistEditorOpen(
      true
    );
  }


  function updatePlaylistDraft(
    field,
    value
  ) {
    setPlaylistDraft(
      (current) => ({
        ...current,

        [field]:
          value,
      })
    );
  }


  async function savePlaylistDraftAndClose() {
    const savedId =
      await savePlaylist(
        playlistDraft,
        null,
        false
      );

    if (!savedId) {
      return;
    }

    const savedPlaylist = {
      ...playlistDraft,
      playlist_id: savedId,
    };

    setPlaylist(savedPlaylist);

    // Close this editor before notifying a parent that may replace
    // the PlaylistEditor instance (Project -> newly created playlist).
    setPlaylistEditorOpen(false);

    if (
      typeof onSaved ===
        "function"
    ) {
      await onSaved(
        savedId,
        savedPlaylist
      );
    }
  }


  function updateItem(
    clientKey,
    field,
    value
  ) {
    let nextValue =
      value;

    if (
      typeof nextValue ===
      "string"
    ) {
      nextValue =
        nextValue
          .replace(
            /&mdash;/gi,
            "—"
          )
          .replace(
            /--/g,
            "—"
          );
    }

    setItems(
      (current) =>
        current.map(
          (item) => {
            if (
              item
                ._clientKey !==
              clientKey
            ) {
              return item;
            }

            const nextItem = {
              ...item,

              [field]:
                nextValue,
            };

            if (
              field ===
                "item_type"
              &&
              [
                "hue-wheel",
                "brand-bumper",
              ].includes(
                nextValue
              )
            ) {
              if (
                !String(
                  item.body ||
                  ""
                ).trim()
              ) {
                nextItem.body =
                  nextValue ===
                    "brand-bumper"
                    ? BRAND_BUMPER_BODY_TEMPLATE
                    : HUE_WHEEL_BODY_TEMPLATE;
              }



              nextItem.palette_hash =
                "";

              nextItem.image_url =
                "";

              nextItem.photo_library_id =
                "";



              nextItem.is_share_image =
                false;

              nextItem.star =
                false;

              if (
                nextValue ===
                "brand-bumper"
              ) {
                nextItem.title =
                  nextItem.title ||
                  "ColorFix";

                nextItem.subtitle =
                  nextItem.subtitle ||
                  "by Terry";

                nextItem.site =
                  true;

                nextItem.yt =
                  true;

                nextItem.concept =
                  true;

                nextItem.showcase =
                  true;

                nextItem.client =
                  true;

                nextItem.pin =
                  false;

                nextItem.analyzer_role =
                  "single";

                nextItem.duration_ms =
                  nextItem.duration_ms ||
                  "4200";
              }
            }

            return nextItem;
          }
        )
    );

    markDirty();
  }


  function addItem(
    presetKey
  ) {
    const preset =
      insertionPresets.find(
        (row) =>
          row
            ?.option_key ===
          presetKey
      );

    if (
      !preset
      ||
      preset.is_enabled ===
        false
    ) {
      setSlidePresetsError(
        "That slide default is not available."
      );

      return;
    }

    const item =
      buildPresetItem(
        preset,
        makeClientItemKey()
      );

    const insertPosition =
      String(
        preset
          .insert_position ||
        "after_selected"
      ).trim();

    setItems(
      (current) => {
        const activeIndex =
          current.findIndex(
            (row) =>
              row
                ._clientKey ===
              selectedSlideKey
          );

        let insertIndex =
          current.length;

        if (
          insertPosition ===
          "top"
        ) {
          insertIndex =
            0;

        } else if (
          insertPosition ===
          "bottom"
        ) {
          insertIndex =
            current.length;

        } else if (
          insertPosition ===
          "before_selected"
        ) {
          insertIndex =
            activeIndex >= 0
              ? activeIndex
              : 0;

        } else if (
          activeIndex >= 0
        ) {
          insertIndex =
            activeIndex + 1;
        }

        const next = [
          ...current,
        ];

        next.splice(
          insertIndex,
          0,
          item
        );

        return next;
      }
    );

    setSelectedSlideKey(
      item._clientKey
    );

    markDirty();
  }


  async function removeItem(
    clientKey
  ) {
    const item =
      items.find(
        (row) =>
          row
            ._clientKey ===
          clientKey
      );

    if (!item) {
      return false;
    }

    const confirmed =
      await dialog.confirm({
        title:
          "Remove slide?",

        message:
          `Remove ${
            item.title
              ? `"${item.title}"`
              : `slide #${itemIndex(items, item) + 1}`
          } from this playlist?`,

        confirmLabel:
          "Remove",

        cancelLabel:
          "Cancel",
      });

    if (
      !confirmed
    ) {
      return false;
    }

    setItems(
      (current) =>
        current.filter(
          (row) =>
            row
              ._clientKey !==
            clientKey
        )
    );

    setSelectedSlideKey(
      (current) =>
        current ===
          clientKey
          ? null
          : current
    );

    markDirty();

    return true;
  }


  const slideDragSensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  function moveSlide(from, to) {
    if (saving || from === to || from < 0 || to < 0 || to >= items.length) return;
    setItems((current) => {
      const next = [...current];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
    markDirty();
  }

  function handleSlideDragEnd({ active, over }) {
    if (!over || active.id === over.id) return;
    moveSlide(
      items.findIndex((item) => item._clientKey === active.id),
      items.findIndex((item) => item._clientKey === over.id)
    );
  }

  function clearItemPhoto(
    clientKey
  ) {
    setItems(
      (current) =>
        current.map(
          (item) =>
            item
              ._clientKey ===
            clientKey
              ? {
                  ...item,

                  photo_library_id:
                    "",

                  image_url:
                    "",

                  is_share_image:
                    false,
                }
              : item
        )
    );

    markDirty();
  }


  function setShareImage(
    clientKey
  ) {
    setItems(
      (current) =>
        current.map(
          (item) => ({
            ...item,

            is_share_image:
              item
                ._clientKey ===
                clientKey
              &&
              hasItemPhoto(
                item
              ),
          })
        )
    );

    markDirty();
  }


  async function applyAttachedPaletteFromPhoto(clientKey, photoLibraryId, attachedInfo = null) {
    const info = attachedInfo || photoInfo[String(photoLibraryId || "").trim()];
    try {
      const palette = await resolvePhotoPalette(info?.attachedSavedPaletteId, savedOptions, API_FOLDER);
      if (palette) setSavedOptions((current) => [...current.filter((row) => Number(row.id) !== Number(palette.id)), palette]);
      setItems((current) => current.map((item) =>
        item._clientKey === clientKey && Number(getPhotoLibraryId(item)) === Number(photoLibraryId)
          ? { ...item, palette_hash: palette?.palette_hash || "" }
          : item));
      markDirty();
    } catch (error) {
      await dialog.alert({ title: "Photo palette could not be loaded", message: error.message });
    }
  }

  async function confirmPhotoReplacement(photoId) {
    return dialog.confirm({
      title: `Replace Photo #${photoId}?`,
      message: "This permanently replaces the image everywhere this photo is used, including PVs. The photo number, palette, Use flag, and role stay the same. The old image will be deleted.",
      confirmLabel: "Replace Photo",
      cancelLabel: "Cancel",
    });
  }

  function applyReplacedPhoto(photo) {
    const pid = String(photo.photo_library_id);
    const imageUrl = photo.image_url || photo.rel_path;
    setPhotoThumbs((current) => ({ ...current, [pid]: imageUrl }));
    setPhotoInfo((current) => ({ ...current, [pid]: current[pid] || photoInfoFromRow(photo) }));
    setItems((current) => current.map((item) => Number(getPhotoLibraryId(item)) === Number(pid)
      ? { ...item, image_url: makePhotoRef(pid, imageUrl) } : item));
    markDirty();
  }

  async function pickSlidePhoto(clientKey, photo) {
    const item = items.find((row) => row._clientKey === clientKey);
    const oldId = Number(getPhotoLibraryId(item));
    const newId = Number(photo?.photo_library_id);
    if (!oldId) { applyPhotoToItem(clientKey, photo); return; }
    if (oldId === newId || !await confirmPhotoReplacement(oldId)) return;
    try {
      const body = new FormData();
      body.append("photo_library_id", String(oldId));
      body.append("source_photo_library_id", String(newId));
      const response = await fetch(`${API_FOLDER}/v2/admin/photo-library/replace.php`, { method: "POST", credentials: "include", body });
      const data = await response.json();
      if (!response.ok || !data.ok || !data.photo) throw new Error(data.error || "Could not replace photo.");
      applyReplacedPhoto(data.photo);
    } catch (err) { await dialog.alert({ title: "Photo replacement failed", message: err.message }); }
  }

  function applyPhotoToItem(
    clientKey,
    photo
  ) {
    if (
      !clientKey
      ||
      !photo
        ?.photo_library_id
    ) {
      return;
    }

    const pid =
      String(
        photo
          .photo_library_id
      );

    const imageUrl =
      String(
        photo
          .image_url
        ||
        photo
          .file_path
        ||
        photo
          .raw_rel_path
        ||
        ""
      );

    const info =
      photoInfoFromRow(
        photo
      );

    setPhotoInfo(
      (current) => ({
        ...current,

        [pid]:
          info,
      })
    );

    updateItem(
      clientKey,
      "photo_library_id",
      pid
    );

    updateItem(
      clientKey,
      "image_url",
      makePhotoRef(
        pid,
        imageUrl
      )
    );

    applyAttachedPaletteFromPhoto(
      clientKey,
      pid,
      info
    );

    if (
      imageUrl
    ) {
      setPhotoThumbs(
        (current) => ({
          ...current,

          [pid]:
            imageUrl,
        })
      );
    }
  }


  function copySelectedSlides() {
    if (
      batchSelectedKeys.length ===
      0
    ) {
      return;
    }

    const selected =
      new Set(
        batchSelectedKeys
      );

    const copiedSlides =
      items.filter(
        (item) =>
          selected.has(
            item._clientKey
          )
      );

    if (
      copiedSlides.length ===
      0
    ) {
      return;
    }

    const stored =
      writeSlideClipboard(
        copiedSlides,
        playlist
          ?.playlist_id
        ||
        null
      );

    setSlideClipboardCount(
      stored.length
    );

    setSaveMessage(
      `${stored.length} slide${stored.length === 1 ? "" : "s"} copied.`
    );
  }


  function pasteCopiedSlides() {
    const copiedSlides =
      readSlideClipboard();

    if (
      copiedSlides.length ===
      0
    ) {
      setSlideClipboardCount(
        0
      );

      return;
    }

    const pastedSlides =
      copiedSlides.map(
        (item) =>
          clonePlaylistItemForNewPlaylist(
            item,
            makeClientItemKey()
          )
      );

    const pastedKeys =
      pastedSlides.map(
        (item) =>
          item._clientKey
      );

    const anchorKey =
      selectedSlideKey
      ||
      (
        batchSelectedKeys.length ===
        1
          ? batchSelectedKeys[0]
          : null
      );

    setItems(
      (current) => {
        const anchorIndex =
          anchorKey
            ? current.findIndex(
                (item) =>
                  item
                    ._clientKey ===
                  anchorKey
              )
            : -1;

        const insertIndex =
          anchorIndex >= 0
            ? anchorIndex + 1
            : current.length;

        const next = [
          ...current,
        ];

        next.splice(
          insertIndex,
          0,
          ...pastedSlides
        );

        return next;
      }
    );

    setBatchSelectedKeys(
      pastedKeys
    );

    setSelectedSlideKey(
      null
    );

    markDirty();

    setSaveMessage(
      `${pastedSlides.length} slide${pastedSlides.length === 1 ? "" : "s"} pasted. Save to keep ${pastedSlides.length === 1 ? "it" : "them"}.`
    );
  }


  async function createPlaylistFromSelected() {
    if (
      batchSelectedKeys.length ===
      0
    ) {
      return;
    }

    const selected =
      new Set(
        batchSelectedKeys
      );

    const copiedSlides =
      items.filter(
        (item) =>
          selected.has(
            item._clientKey
          )
      );

    if (
      copiedSlides.length ===
      0
    ) {
      return;
    }

    if (
      dirty
    ) {
      const continueCreate =
        await dialog.confirm({
          title:
            "Create playlist from selected slides?",

          message:
            "The selected slides will be copied exactly as they are now. Other unsaved changes in this playlist will be discarded when you leave it.",

          confirmLabel:
            "Continue",

          cancelLabel:
            "Stay",
        });

      if (
        !continueCreate
      ) {
        return;
      }
    }

    navigate(
      "/admin/playlists/new",
      {
        state: {
          copiedSlides,
          sourcePlaylistId:
            playlist
              .playlist_id
            ||
            null,
        },
      }
    );
  }


  async function deleteSelectedSlides() {
    if (
      batchSelectedKeys.length ===
      0
    ) {
      return;
    }

    const selected =
      new Set(
        batchSelectedKeys
      );

    const nextItems =
      items.filter(
        (item) =>
          !selected.has(
            item._clientKey
          )
      );

    const deleteCount =
      items.length -
      nextItems.length;

    if (
      deleteCount ===
      0
    ) {
      return;
    }

    const confirmed =
      await dialog.confirm({
        title:
          `Delete ${deleteCount} selected slide${deleteCount === 1 ? "" : "s"}?`,

        message:
          "The selected slides will be removed from this playlist. Their photos and other source records are not deleted.",

        confirmLabel:
          "Delete",

        cancelLabel:
          "Cancel",
      });

    if (
      !confirmed
    ) {
      return;
    }

    setItems(
      nextItems
    );

    setBatchSelectedKeys([]);
    setSelectedSlideKey(null);
    markDirty();
  }


  async function savePlaylist(
    playlistOverride = null,
    itemsOverride = null,
    notifySaved = true
  ) {
    const hasPlaylistOverride =
      playlistOverride
      &&
      typeof playlistOverride ===
        "object"
      &&
      Object.prototype.hasOwnProperty.call(
        playlistOverride,
        "title"
      );

    const playlistToSave =
      hasPlaylistOverride
        ? playlistOverride
        : playlist;

    const itemsToSave =
      Array.isArray(
        itemsOverride
      )
        ? itemsOverride
        : items;

    setSaving(
      true
    );

    setDetailError(
      ""
    );

    setSaveMessage(
      ""
    );

    try {
      const res =
        await fetch(
          SAVE_URL,
          {
            method:
              "POST",

            credentials:
              "include",

            headers: {
              "Content-Type":
                "application/json",
            },

            body:
              JSON.stringify({
                playlist_id:
                  playlistToSave.playlist_id,

                project_id:
                  playlistToSave.project_id
                    ? Number(
                        playlistToSave.project_id
                      )
                    : null,

                title:
                  playlistToSave.title,

                type:
                  playlistToSave.type,

                is_active:
                  Boolean(
                    playlistToSave.is_active
                  ),

                is_public:
                  Boolean(
                    playlistToSave.is_public
                  ),

                slug:
                  playlistToSave.slug,

                headline:
                  playlistToSave.headline,

                page_title:
                  playlistToSave.page_title,

                meta_description:
                  playlistToSave.meta_description,

                dek:
                  playlistToSave.dek,

                intro_html:
                  playlistToSave.intro_html,

                body_html:
                  playlistToSave.body_html,

                hero_image_id:
                  playlistToSave.hero_image_id
                    ? playlistToSave.hero_image_id
                    : null,

                hero_image_url:
                  playlistToSave.hero_image_url,

                hero_alt:
                  playlistToSave.hero_alt,

                indexable:
                  Boolean(
                    playlistToSave.indexable
                  ),

                published_at:
                  playlistToSave.published_at
                    ? playlistToSave.published_at
                    : null,
              }),
          }
        );

      const data =
        await res.json();

      if (
        !res.ok
        ||
        !data?.ok
      ) {
        throw new Error(
          data?.error ||
          "Failed to save playlist."
        );
      }

      const id =
        Number(
          data
            .playlist_id ||
          playlist
            .playlist_id ||
          0
        );

      if (!id) {
        throw new Error(
          "Playlist save returned no playlist ID."
        );
      }

      const itemsRes =
        await fetch(
          SAVE_ITEMS_URL,
          {
            method:
              "POST",

            credentials:
              "include",

            headers: {
              "Content-Type":
                "application/json",
            },

            body:
              JSON.stringify({
                playlist_id:
                  id,

                items:
                  itemsToSave.map(
                    serializePlaylistItem
                  ),
              }),
          }
        );

      const itemsData =
        await itemsRes.json();

      if (
        !itemsRes.ok
        ||
        !itemsData?.ok
      ) {
        throw new Error(
          itemsData?.error ||
          "Failed to save playlist items."
        );
      }

      setDirty(
        false
      );

      setPlaylists(
        (current) =>
          upsertPlaylistSummary(
            current,
            {
              playlist_id:
                id,

              project_id:
                playlistToSave.project_id
                  ? Number(
                      playlistToSave.project_id
                    )
                  : null,

              title:
                playlistToSave.title,

              type:
                playlistToSave.type,

              is_active:
                playlistToSave.is_active
                  ? 1
                  : 0,

              is_public:
                playlistToSave.is_public
                  ? 1
                  : 0,
            }
          )
      );

      setSaveMessage(
        "Saved"
      );

      if (
        notifySaved
        &&
        typeof onSaved ===
          "function"
      ) {
        await onSaved(
          id,
          {
            ...playlistToSave,
            playlist_id: id,
          }
        );
      }

      return id;

    } catch (err) {
      setDetailError(
        err?.message ||
        "Save failed."
      );

      return null;

    } finally {
      setSaving(
        false
      );
    }
  }


  async function analyzePlaylist() {
    const id =
      await savePlaylist();

    if (!id) {
      return;
    }

    navigate(
      `/admin/pub?stage=analyze&playlist_id=${encodeURIComponent(String(id))}`
    );
  }


  async function saveAndPlay() {
    const experienceKey =
      String(
        playerExperience ||
        ""
      )
        .trim()
        .toLowerCase();

    if (!experienceKey) {
      setDetailError(
        "Choose a Play As experience first."
      );

      return;
    }

    const id =
      Number(
        playlist?.playlist_id ||
        routePlaylistId ||
        0
      );

    if (!id) {
      setDetailError(
        "Save & Close the playlist before playing it."
      );

      return;
    }

    setDetailError("");

    async function getRexUrl() {
      const params =
        new URLSearchParams();

      params.set(
        "playlist_id",
        String(id)
      );

      params.set(
        "experience_key",
        experienceKey
      );

      params.set(
        "_",
        String(Date.now())
      );

      const res =
        await fetch(
          `${REX_PLAYLIST_URL}?${params.toString()}`,
          {
            credentials:
              "include",
          }
        );

      const data =
        await res.json();

      if (
        !res.ok
        ||
        !data?.ok
      ) {
        throw new Error(
          data?.error
          ||
          "Could not load the playlist REX."
        );
      }

      return String(
        data
          ?.item
          ?.public_url
        ||
        ""
      ).trim();
    }

    try {
      let publicUrl =
        await getRexUrl();

      /*
       * Play always uses the real REX-backed experience.
       * If this experience has never had a REX, re-save the
       * current slide set to trigger the normal REX sync once.
       */
      if (!publicUrl) {
        const syncRes =
          await fetch(
            SAVE_ITEMS_URL,
            {
              method:
                "POST",

              credentials:
                "include",

              headers: {
                "Content-Type":
                  "application/json",
              },

              body:
                JSON.stringify({
                  playlist_id:
                    id,

                  items:
                    items.map(
                      serializePlaylistItem
                    ),
                }),
            }
          );

        const syncData =
          await syncRes.json();

        if (
          !syncRes.ok
          ||
          !syncData?.ok
        ) {
          throw new Error(
            syncData?.error
            ||
            `Could not create the ${experienceKey} REX.`
          );
        }

        publicUrl =
          await getRexUrl();
      }

      if (!publicUrl) {
        throw new Error(
          `Could not create the ${experienceKey} REX URL.`
        );
      }

      const playerUrl =
        new URL(
          publicUrl,
          window.location.origin
        );

      playerUrl.searchParams.set(
        "fresh",
        "1"
      );

      playerUrl.searchParams.set(
        "src",
        "admin"
      );

      playerUrl.searchParams.set(
        "close",
        "1"
      );

      playerUrl.searchParams.set(
        "_",
        String(
          Date.now()
        )
      );

      playerUrl.searchParams.set(
        "return_to",
        `${window.location.pathname}${window.location.search}`
      );

      window.open(
        playerUrl.toString(),
        "_blank",
        "noopener"
      );

    } catch (err) {
      setDetailError(
        err?.message
        ||
        "The playlist could not be opened."
      );
    }
  }


  async function deletePlaylist() {
    const id =
      Number(
        playlist
          ?.playlist_id ||
        0
      );

    if (!id) {
      return;
    }

    const confirmed =
      await dialog.confirm({
        title:
          "Delete playlist?",

        message:
          `Delete playlist #${id} and its playlist items?`,

        confirmLabel:
          "Delete",

        cancelLabel:
          "Cancel",
      });

    if (
      !confirmed
    ) {
      return;
    }

    setDeleting(
      true
    );

    setDetailError(
      ""
    );

    try {
      const res =
        await fetch(
          DELETE_URL,
          {
            method:
              "POST",

            credentials:
              "include",

            headers: {
              "Content-Type":
                "application/json",
            },

            body:
              JSON.stringify({
                playlist_id:
                  id,
              }),
          }
        );

      const text =
        await res.text();

      if (
        !res.ok
      ) {
        throw new Error(
          `HTTP ${res.status}: ${text.slice(0, 200)}`
        );
      }

      const data =
        JSON.parse(
          text
        );

      if (
        !data?.ok
      ) {
        throw new Error(
          data?.error ||
          "Delete failed."
        );
      }

      setPlaylistEditorOpen(
        false
      );

      setDirty(
        false
      );

      if (
        typeof onDeleted ===
        "function"
      ) {
        onDeleted(
          id
        );
      } else {
        navigate(
          "/admin/playlists",
          {
            replace:
              true,
          }
        );
      }

    } catch (err) {
      setDetailError(
        err?.message ||
        "Delete failed."
      );

    } finally {
      setDeleting(
        false
      );
    }
  }


  const slideColumns =
    useMemo(
      () => [
        {
          key:
            "__move",

          label:
            "",

          sortable:
            false,

          render:
            () => <PlaylistSlideDragHandle />,
        },

        {
          key:
            "__order",

          label:
            "#",

          sortable:
            false,

          value:
            (item) =>
              itemIndex(items,
                item
              ) + 1,
        },

        {
          key:
            "photo",

          label:
            "Photo",

          sortable:
            false,

          render:
            (item) => {
              const src =
                getItemPhotoThumb(
                  item,
                  photoThumbs
                );

              return src
                ? (
                    <button
                      type="button"
                      aria-label={`Enlarge ${item.title || "slide photo"}`}
                      style={{ display: "block", padding: 0, border: 0, background: "transparent", cursor: "zoom-in" }}
                      onPointerDown={(event) => event.stopPropagation()}
                      onDoubleClick={(event) => event.stopPropagation()}
                      onKeyDown={(event) => event.stopPropagation()}
                      onClick={(event) => {
                        event.stopPropagation();
                        setPreviewPhoto({ url: parsePhotoRef(item.image_url || "").url || src, alt: item.title || "" });
                      }}
                    >
                      <img
                        {...photoImageProps(getPhotoLibraryId(item), src, { width: 160 })}
                        alt=""
                        width="64"
                        loading="lazy"
                      />
                    </button>
                  )
                : "—";
            },
        },

        {
          key:
            "item_type",

          label:
            "Type",

          sortable:
            false,

          value:
            (item) =>
              slideTypeLabel(
                item
                  .item_type
              ),
        },

        {
          key:
            "title",

          label:
            "Title",

          sortable:
            false,

          value:
            (item) =>
              item.title ||
              "—",
        },

        {
          key:
            "analyzer_role",

          label:
            "Role",

          sortable:
            false,

          value:
            (item) =>
              humanize(
                item
                  .analyzer_role
              ),
        },

        {
          key:
            "venues",

          label:
            "Use",

          sortable:
            false,

          value:
            (item) =>
              slideUsageLabel(
                item
              ),
        },

        {
          key:
            "active",

          label:
            "Active",

          sortable:
            false,

          render:
            (item) => (
              <AdminBadge
                variant={
                  item
                    .is_active
                    ? "success"
                    : "neutral"
                }
              >
                {
                  item
                    .is_active
                    ? "Yes"
                    : "No"
                }
              </AdminBadge>
            ),
        },

      ],
      [
        items,
        photoThumbs,
      ]
    );


  const currentTitle =
    playlist.title
    ||
    (
      isNewRoute
        ? "New Playlist"
        : "Playlist"
    );


  useImperativeHandle(
    ref,
    () => ({
      isDirty: () =>
        dirty,

      saveIfDirty:
        async () =>
          !dirty,
    }),
    [
      dirty,
      playlist,
      items,
      selectedSlideKey,
    ]
  );


  const primaryActions = (
    <AdminToolbar>
      <AdminButton
        type="button"
        variant="secondary"
        disabled={saving || isNewRoute}
        onClick={beginNewPlaylist}
      >
        New
      </AdminButton>

      <AdminButton
        type="button"
        variant="secondary"
        disabled={saving}
        onClick={openPlaylistEditor}
      >
        Edit
      </AdminButton>

      <AdminButton
        type="button"
        variant="primary"
        disabled={saving || !dirty}
        onClick={() => savePlaylist()}
      >
        {saving ? "Saving..." : "Save"}
      </AdminButton>

      <AdminButton
        type="button"
        variant="secondary"
        disabled={saving || !items.length}
        onClick={analyzePlaylist}
      >
        Analyzer
      </AdminButton>

      <AdminButton
        type="button"
        variant="secondary"
        disabled={saving}
        onClick={saveAndPlay}
      >
        Play
      </AdminButton>

      {isMobile ? (
        <div
          className="mobile-playlist-play-as"
          onClick={(event) => event.stopPropagation()}
        >
          <MobileSelect
            title="Play As"
            placeholder="Play As"
            value={playerExperience || ""}
            onChange={setPlayerExperience}
            options={[
              { value: "concept", label: "Concept" },
              { value: "client", label: "Client" },
              { value: "showcase", label: "Showcase" },
              { value: "public", label: "Public Full" },
            ]}
          />
        </div>
      ) : (
      <label style={{ display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
        Play As
        <select
          className="admin-field__control"
          aria-label="Play As"
          style={{ width: 132, minWidth: 0, flex: "none" }}
          value={playerExperience || ""}
          onChange={(event) =>
            setPlayerExperience(
              event.target.value
            )
          }
        >
          <option value="">
            Choose…
          </option>
          <option value="concept">
            Concept
          </option>
          <option value="client">
            Client
          </option>
          <option value="showcase">
            Showcase
          </option>
          <option value="public">
            Public Full
          </option>
        </select>
      </label>
      )}

      <AdminButton
        type="button"
        variant="secondary"
        disabled={
          slidePresetsLoading ||
          slidePresets.length === 0
        }
        onClick={() =>
          setSlideDefaultsOpen(true)
        }
      >
        Slide Defaults
      </AdminButton>

      <PlaylistRexButton
        playlistId={
          Number(
            playlist?.playlist_id ||
            routePlaylistId ||
            0
          )
        }
        title={
          playlist?.title ||
          ""
        }
        disabled={saving}
      />
    </AdminToolbar>
  );

  const secondaryActions = (
    <AdminToolbar compact>
      <AdminField
        label="Insert"
        compact
      >
        <select
          className="admin-field__control"
          value=""
          onChange={(event) => {
            const preset =
              event.target.value;

            if (preset) {
              addItem(preset);
            }
          }}
        >
          <option value="">
            {
              slidePresetsLoading
                ? "Loading defaults…"
                : "Insert New…"
            }
          </option>

          {
            insertionPresets
              .map(
                (preset) => (
                  <option
                    key={preset.option_key}
                    value={preset.option_key}
                  >
                    {
                      preset.label ||
                      preset.preset_key
                    }
                  </option>
                )
              )
          }
        </select>
      </AdminField>

      <AdminField
        label="Selection"
        compact
      >
        <AdminToolbar compact>
          <AdminButton
            type="button"
            variant="secondary"
            disabled={
              batchSelectedKeys.length === 0
            }
            onClick={copySelectedSlides}
          >
            Copy
          </AdminButton>

          <AdminButton
            type="button"
            variant="secondary"
            disabled={
              slideClipboardCount === 0 ||
              saving
            }
            onClick={pasteCopiedSlides}
          >
            Paste
            {
              slideClipboardCount
                ? ` (${slideClipboardCount})`
                : ""
            }
          </AdminButton>

          <AdminButton
            type="button"
            variant="secondary"
            disabled={
              batchSelectedKeys.length === 0
            }
            onClick={createPlaylistFromSelected}
          >
            New Playlist
          </AdminButton>

          <AdminButton
            type="button"
            variant="secondary"
            disabled={
              batchSelectedKeys.length === 0 ||
              saving
            }
            onClick={deleteSelectedSlides}
          >
            Delete
          </AdminButton>

          {batchSelectedKeys.length ? (
            <AdminMetaText as="div">
              {batchSelectedKeys.length} selected
            </AdminMetaText>
          ) : null}
        </AdminToolbar>
      </AdminField>

      <AdminMetaText as="div">
        {items.length} slide
        {items.length === 1 ? "" : "s"}
      </AdminMetaText>
    </AdminToolbar>
  );


  return (
    <>
      <AdminDetailPane
        ariaLabel="Playlist"
        title={currentTitle}
        jumpToId={typeof onJumpPlaylistId === "function" ? {
          label: "Playlist #",
          onJump: onJumpPlaylistId,
        } : null}
        actions={
          (detailLoading || detailError) && !isNewRoute
            ? null
            : primaryActions
        }
        subActions={
          (detailLoading || detailError) && !isNewRoute
            ? null
            : secondaryActions
        }
      >
        {
          detailLoading
          &&
          !isNewRoute
            ? (
                <AdminEmptyState
                  title="Playlist"
                  message="Loading playlist..."
                />
              )
            : (
                <AdminStack gap="sm">



                  {
                    detailError
                      ? (
                          <AdminNotice variant="danger">
                            <div>{detailError}</div>
                            <AdminButton onClick={() => fetchPlaylist(routePlaylistId)}>Retry</AdminButton>
                          </AdminNotice>
                        )
                      : null
                  }


                  {
                    saveMessage
                      ? (
                          <AdminNotice variant="success">
                            {saveMessage}
                          </AdminNotice>
                        )
                      : null
                  }





                  {
                    slidePresetsError
                      ? (
                          <AdminNotice variant="danger">
                            {slidePresetsError}
                          </AdminNotice>
                        )
                      : null
                  }


                  {
                    items.length
                      ? (
                          <DndContext sensors={slideDragSensors} collisionDetection={closestCenter} onDragEnd={handleSlideDragEnd}>
                          <AdminSmartGrid
                            renderRow={(row, item) => (
                              <PlaylistSlideDragRow key={item._clientKey} row={row} item={item}
                                index={itemIndex(items, item)} disabled={saving || items.length < 2} onMove={moveSlide} />
                            )}
                            items={
                              items
                            }

                            columns={
                              slideColumns
                            }

                            getRowKey={(
                              item
                            ) =>
                              item
                                ._clientKey
                            }

                            multiSelect

                            batchSelectedKeys={
                              batchSelectedKeys
                            }

                            onBatchSelectionChange={(
                              keys
                            ) =>
                              setBatchSelectedKeys(
                                keys
                              )
                            }

                            selectedKey={
                              selectedSlideKey
                            }

                            onSelectionChange={(
                              item
                            ) =>
                              setSelectedSlideKey(
                                item
                                  ?._clientKey
                                ||
                                null
                              )
                            }

                            drawer={{
                              title:
                                (item) =>
                                  `Slide ${
                                    itemIndex(
                                      items,
                                      item
                                    ) + 1
                                  } · ${
                                    item.title
                                    ||
                                    slideTypeLabel(
                                      item.item_type
                                    )
                                  }`,

                              width:
                                620,

                              padded:
                                true,

                              closeLabel:
                                "Save & Close",

                              beforeClose:
                                async () => {
                                  const savedId =
                                    await savePlaylist();

                                  if (!savedId) {
                                    return false;
                                  }

                                  return await fetchPlaylist(savedId, null, false);
                                },

                              footer:
                                ({
                                  close,
                                  closing,
                                }) => (
                                  <button
                                    type="button"
                                    className="admin-button admin-button--primary"
                                    disabled={
                                      saving
                                      ||
                                      closing
                                    }
                                    onClick={
                                      close
                                    }
                                  >
                                    {saving || closing
                                      ? "Saving..."
                                      : "Save & Close"}
                                  </button>
                                ),

                              render:
                                ({
                                  item,
                                  close,
                                }) => {
                                  const liveItem =
                                    items.find(
                                      (row) =>
                                        row
                                          ._clientKey ===
                                        item
                                          ._clientKey
                                    );

                                  if (
                                    !liveItem
                                  ) {
                                    return (
                                      <AdminEmptyState
                                        title="Slide removed"
                                        message="This slide is no longer in the playlist."
                                      />
                                    );
                                  }

                                  const photoId =
                                    getPhotoLibraryId(
                                      liveItem
                                    );

                                  const info =
                                    photoInfo[
                                      String(
                                        photoId ||
                                        ""
                                      )
                                    ]
                                    ||
                                    null;

                                  return (
                                    <PlaylistSlideEditor
                                      onPhotoPreview={(url, alt) => setPreviewPhoto({ url, alt })}
                                      item={
                                        liveItem
                                      }

                                      slideNumber={
                                        itemIndex(
                                          items,
                                          liveItem
                                        ) + 1
                                      }

                                      photoThumb={
                                        getItemPhotoThumb(
                                          liveItem,
                                          photoThumbs
                                        )
                                      }

                                      photoInfo={
                                        info
                                      }

                                      savedPalettes={
                                        savedOptions
                                      }

                                      projectId={
                                        playlist
                                          .project_id
                                      }

                                      attachedPalette={
                                        getDisplayPaletteInfo(
                                          liveItem,
                                          photoInfo
                                        )
                                      }

                                      shareImageActive={
                                        resolvedShareItemKey ===
                                        liveItem
                                          ._clientKey
                                      }

                                      onUpdate={(
                                        field,
                                        value
                                      ) =>
                                        updateItem(
                                          liveItem
                                            ._clientKey,
                                          field,
                                          value
                                        )
                                      }

                                      onPickPhoto={() =>
                                        setPhotoPickerKey(
                                          liveItem
                                            ._clientKey
                                        )
                                      }

                                      onConfirmReplacePhoto={() => confirmPhotoReplacement(getPhotoLibraryId(liveItem))}
                                      onUploadPhoto={(photo) =>
                                        getPhotoLibraryId(liveItem) ? applyReplacedPhoto(photo) : applyPhotoToItem(
                                          liveItem
                                            ._clientKey,
                                          photo
                                        )
                                      }

                                      onClearPhoto={() =>
                                        clearItemPhoto(
                                          liveItem
                                            ._clientKey
                                        )
                                      }

                                      onSetShareImage={() =>
                                        setShareImage(
                                          liveItem
                                            ._clientKey
                                        )
                                      }

                                      onPickColorPlan={() =>
                                        setColorPlanPickerKey(
                                          liveItem
                                            ._clientKey
                                        )
                                      }

                                      onRemove={
                                        async () => {
                                          const removed =
                                            await removeItem(
                                              liveItem
                                                ._clientKey
                                            );

                                          if (
                                            removed
                                          ) {
                                            // Local only. Save & Close commits
                                            // the complete playlist.
                                          }
                                        }
                                      }

                                      saving={
                                        saving
                                      }

                                      saveError={
                                        detailError
                                      }

                                    />
                                  );
                                },
                            }}

                            ariaLabel="Playlist slides"
                          />
                          </DndContext>
                        )
                      : (
                          <AdminEmptyState
                            title="No slides"
                            message="Use Insert New to add the first slide."
                          />
                        )
                  }
                </AdminStack>
              )
        }
      </AdminDetailPane>

      <PhotoPreview src={previewPhoto?.url || ""} alt={previewPhoto?.alt || ""} onClose={() => setPreviewPhoto(null)} />

      <AdminEditor
        open={
          playlistEditorOpen
        }

        title={
          playlistDraft
            .playlist_id
            ? `Edit Playlist #${playlistDraft.playlist_id}`
            : "New Playlist"
        }

        meta={
          playlistDraft
            .type
            ? playlistDraft.type
            : null
        }

        width={
          920
        }

        busy={
          saving
          ||
          deleting
        }

        onClose={() =>
          setPlaylistEditorOpen(
            false
          )
        }
      >
        <PlaylistRecordEditor
          playlist={
            playlistDraft
          }

          playlistTypes={
            playlistTypes
          }

          projects={
            projects
          }

          busy={
            saving
            ||
            deleting
          }

          onChange={
            updatePlaylistDraft
          }

          onPickHero={() =>
            setHeroPickerOpen(
              true
            )
          }

          onClearHero={() => {
            updatePlaylistDraft(
              "hero_image_id",
              ""
            );

            updatePlaylistDraft(
              "hero_image_url",
              ""
            );
          }}

          onGenerateSlug={() =>
            updatePlaylistDraft(
              "slug",
              slugifyPlaylistValue(
                playlistDraft.headline
                ||
                playlistDraft.title
              )
            )
          }

          onClose={() =>
            setPlaylistEditorOpen(
              false
            )
          }

          onSaveAndClose={
            savePlaylistDraftAndClose
          }

          onDelete={
            playlistDraft
              .playlist_id
              ? deletePlaylist
              : null
          }
        />
      </AdminEditor>


      <SlideDefaultsDialog
        open={
          slideDefaultsOpen
        }

        presets={
          slidePresets
        }

        onClose={() =>
          setSlideDefaultsOpen(
            false
          )
        }

        onSaved={(
          saved
        ) => {
          setSlidePresets(
            (current) => {
              const exists =
                current.some(
                  (row) =>
                    row
                      ?.preset_key ===
                    saved
                      ?.preset_key
                );

              const next =
                exists
                  ? current.map(
                      (row) =>
                        row
                          ?.preset_key ===
                        saved
                          ?.preset_key
                          ? saved
                          : row
                    )
                  : [
                      ...current,
                      saved,
                    ];

              return next.sort(
                (
                  a,
                  b
                ) => {
                  const byOrder =
                    Number(
                      a
                        ?.sort_order ||
                      0
                    )
                    -
                    Number(
                      b
                        ?.sort_order ||
                      0
                    );

                  if (
                    byOrder !==
                    0
                  ) {
                    return byOrder;
                  }

                  return String(
                    a
                      ?.label ||
                    a
                      ?.preset_key ||
                    ""
                  ).localeCompare(
                    String(
                      b
                        ?.label ||
                      b
                        ?.preset_key ||
                      ""
                    )
                  );
                }
              );
            }
          );

          setSlidePresetsError(
            ""
          );
        }}
      />


      <PhotoPickerDialog
        open={
          photoPickerKey !=
          null
        }

        onClose={() =>
          setPhotoPickerKey(
            null
          )
        }

        onPick={async (picked) => {
          if (
            !photoPickerKey
          ) {
            return;
          }

          await pickSlidePhoto(
            photoPickerKey,
            picked
          );

          setPhotoPickerKey(
            null
          );
        }}
      />



      <PhotoPickerDialog
        open={
          heroPickerOpen
        }

        title="Pick Hero Photo"

        onClose={() =>
          setHeroPickerOpen(
            false
          )
        }

        onPick={(
          picked
        ) => {
          if (
            !picked
              ?.photo_library_id
          ) {
            return;
          }

          updatePlaylistDraft(
            "hero_image_id",
            String(
              picked
                .photo_library_id
            )
          );

          updatePlaylistDraft(
            "hero_image_url",
            picked
              .image_url ||
            ""
          );

          if (
            !String(
              playlistDraft
                .hero_alt ||
              ""
            ).trim()
          ) {
            updatePlaylistDraft(
              "hero_alt",
              playlistDraft.headline
              ||
              playlistDraft.title
            );
          }setHeroPickerOpen(
            false
          );
        }}
      />


      <ColorPlanPickerModal
        open={
          colorPlanPickerKey !=
          null
        }

        currentPlanId={
          colorPlanPickerKey
            ? items.find(
                (item) =>
                  item
                    ._clientKey ===
                  colorPlanPickerKey
              )
                ?.color_plan_id
              ||
              null
            : null
        }

        onClose={() =>
          setColorPlanPickerKey(
            null
          )
        }

        onSave={({
          colorPlanId,
        }) => {
          if (
            !colorPlanPickerKey
          ) {
            return;
          }

          updateItem(
            colorPlanPickerKey,
            "color_plan_id",
            String(
              colorPlanId
            )
          );

          setColorPlanPickerKey(
            null
          );
        }}
      />
    </>
  );
});

export default PlaylistEditor;



function normalizePlaylist(
  raw = {}
) {
  return {
    ...emptyPlaylist,
    ...raw,

    playlist_id:
      raw.playlist_id
      ??
      null,

    project_id:
      raw.project_id
      ??
      "",

    title:
      raw.title
      ??
      "",

    type:
      raw.type
      ??
      "",

    is_active:
      raw.is_active == null
        ? true
        : Boolean(
            Number(
              raw.is_active
            )
          ),

    is_public:
      raw.is_public == null
        ? false
        : Boolean(
            Number(
              raw.is_public
            )
          ),

    slug:
      raw.slug
      ??
      "",

    headline:
      raw.headline
      ??
      "",

    page_title:
      raw.page_title
      ??
      "",

    meta_description:
      raw.meta_description
      ??
      "",

    dek:
      raw.dek
      ??
      "",

    intro_html:
      raw.intro_html
      ??
      "",

    body_html:
      raw.body_html
      ??
      "",

    hero_image_id:
      raw.hero_image_id
      ??
      "",

    hero_image_url:
      raw.hero_image_url
      ??
      "",

    hero_alt:
      raw.hero_alt
      ??
      "",

    indexable:
      raw.indexable == null
        ? true
        : Boolean(
            Number(
              raw.indexable
            )
          ),

    published_at:
      toDatetimeLocal(
        raw.published_at
        ??
        ""
      ),
  };
}


function normalizePlaylistItem(
  raw = {},
  makeClientItemKey
) {
  const analyzerRole =
    String(
      raw
        .analyzer_role ||
      ""
    )
      .trim()
      .toLowerCase();

  const finderStart =
    String(
      raw
        .finder_start ||
      ""
    )
      .trim()
      .toLowerCase();

  return {
    ...emptyItem,
    ...raw,

    _clientKey:
      raw
        .playlist_item_id
        ? `existing-${raw.playlist_item_id}`
        : makeClientItemKey(),

    playlist_item_id:
      raw
        .playlist_item_id
      ??
      null,



    palette_hash:
      raw
        .palette_hash
      ??
      "",

    image_url:
      raw
        .image_url
      ??
      "",

    photo_library_id:
      raw
        .photo_library_id
      ??
      parsePhotoRef(
        raw
          .image_url ||
        ""
      )
        .photoId
      ??
      "",



    title:
      raw.title
      ??
      "",

    subtitle:
      raw.subtitle
      ??
      "",

    subtitle_2:
      raw
        .subtitle_2
      ??
      "",

    body:
      raw.body
      ??
      "",

    item_type:
      raw
        .item_type
      ??
      "non-palette",

    layout:
      raw.layout
      ??
      "default",

    title_mode:
      raw
        .title_mode
      ??
      "",

    star:
      raw.star ===
        null
        ? true
        : Boolean(
            raw.star
          ),

    transition:
      raw.transition
      ??
      "",

    duration_ms:
      raw
        .duration_ms
      ??
      "",

    exclude_from_thumbs:
      Boolean(
        raw
          .exclude_from_thumbs
      ),

    is_share_image:
      Boolean(
        raw
          .is_share_image
      ),

    site:
      raw.site ==
        null
        ? true
        : Boolean(
            Number(
              raw.site
            )
          ),

    yt:
      raw.yt ==
        null
        ? true
        : Boolean(
            Number(
              raw.yt
            )
          ),

    concept:
      raw.concept ==
        null
        ? true
        : Boolean(
            Number(
              raw.concept
            )
          ),

    showcase:
      raw.showcase ==
        null
        ? true
        : Boolean(
            Number(
              raw.showcase
            )
          ),

    client:
      raw.client ==
        null
        ? true
        : Boolean(
            Number(
              raw.client
            )
          ),

    pin:
      raw.pin ==
        null
        ? true
        : Boolean(
            Number(
              raw.pin
            )
          ),

    color_plan_id:
      raw
        .color_plan_id
      ??
      "",

    version_number:
      Math.max(
        1,
        Number(
          raw
            .version_number ||
          1
        )
      ),

    is_final:
      Boolean(
        Number(
          raw
            .is_final ||
          0
        )
      ),

    analyzer_role:
      ANALYZER_ROLES.includes(
        analyzerRole
      )
        ? analyzerRole
        : "ignore",

    finder_start:
      FINDER_START_VALUES.includes(
        finderStart
      )
        ? finderStart
        : "auto",

    is_active:
      raw
        .is_active ===
        null
        ? true
        : Boolean(
            raw
              .is_active
          ),
  };
}


function buildPresetItem(
  preset,
  clientKey
) {
  const itemType =
    String(
      preset
        ?.item_type ||
      "non-palette"
    ).trim()
    ||
    "non-palette";

  return {
    ...emptyItem,

    _clientKey:
      clientKey,

    item_type:
      itemType,

    body:
      itemType ===
        "hue-wheel"
        ? HUE_WHEEL_BODY_TEMPLATE
        : itemType ===
            "brand-bumper"
          ? BRAND_BUMPER_BODY_TEMPLATE
          : "",

    title:
      preset
        ?.default_title
      ??
      "",

    subtitle:
      preset
        ?.default_subtitle
      ??
      "",

    subtitle_2:
      preset
        ?.default_subtitle_2
      ??
      "",

    layout:
      preset
        ?.default_layout
      ||
      "default",

    title_mode:
      preset
        ?.default_title_mode
      ??
      "",

    star:
      preset
        ?.default_star
      ??
      true,

    transition:
      preset
        ?.default_transition
      ??
      "",

    duration_ms:
      preset
        ?.default_duration_ms
      ??
      "",

    is_active:
      preset
        ?.default_is_active
      ??
      true,

    exclude_from_thumbs:
      preset
        ?.default_exclude_from_thumbs
      ??
      false,

    is_share_image:
      preset
        ?.default_is_share_image
      ??
      false,

    site:
      preset
        ?.default_site
      ??
      true,

    yt:
      preset
        ?.default_yt
      ??
      true,

    pin:
      preset
        ?.default_pin
      ??
      true,

    concept:
      preset
        ?.default_concept
      ??
      true,

    showcase:
      preset
        ?.default_showcase
      ??
      true,

    client:
      preset
        ?.default_client
      ??
      true,

    analyzer_role:
      preset
        ?.default_analyzer_role
      ||
      "ignore",

    finder_start:
      preset
        ?.default_finder_start
      ||
      "auto",

    version_number:
      Math.max(
        1,
        Number(
          preset
            ?.default_version_number
          ||
          1
        )
      ),

    is_final:
      preset
        ?.default_is_final
      ??
      false,
  };
}


function readSlideClipboard() {
  try {
    const raw =
      window
        .sessionStorage
        .getItem(
          SLIDE_CLIPBOARD_KEY
        );

    if (!raw) {
      return [];
    }

    const parsed =
      JSON.parse(
        raw
      );

    return Array.isArray(
      parsed
        ?.slides
    )
      ? parsed.slides
      : [];

  } catch {
    return [];
  }
}


function writeSlideClipboard(
  slides,
  sourcePlaylistId
) {
  const cleanSlides =
    (
      Array.isArray(
        slides
      )
        ? slides
        : []
    ).map(
      (item) => {
        const {
          _clientKey,
          playlist_item_id,
          playlist_id,
          sort_order,
          position,
          ...copy
        } = item || {};

        void _clientKey;
        void playlist_item_id;
        void playlist_id;
        void sort_order;
        void position;

        return copy;
      }
    );

  try {
    window
      .sessionStorage
      .setItem(
        SLIDE_CLIPBOARD_KEY,
        JSON.stringify({
          version:
            1,

          source_playlist_id:
            sourcePlaylistId,

          slides:
            cleanSlides,
        })
      );
  } catch {
    // Keep the editor usable even if browser storage is unavailable.
  }

  return cleanSlides;
}


function clonePlaylistItemForNewPlaylist(
  item,
  clientKey
) {
  const {
    _clientKey,
    playlist_item_id,
    playlist_id,
    sort_order,
    position,
    ...copy
  } = item || {};

  void _clientKey;
  void playlist_item_id;
  void playlist_id;
  void sort_order;
  void position;

  return {
    ...emptyItem,
    ...copy,

    _clientKey:
      clientKey,

    playlist_item_id:
      null,
  };
}


function serializePlaylistItem(
  item
) {
  const {
    _clientKey,
    ...rest
  } = item;

  void _clientKey;

  const analyzerRole =
    String(
      item
        .analyzer_role ||
      ""
    )
      .trim()
      .toLowerCase();

  const finderStart =
    String(
      item
        .finder_start ||
      ""
    )
      .trim()
      .toLowerCase();

  return {
    ...rest,



    palette_hash:
      item
        .palette_hash ===
        ""
        ? null
        : item
            .palette_hash,



    duration_ms:
      item
        .duration_ms ===
        ""
        ? null
        : item
            .duration_ms,

    is_share_image:
      Boolean(
        item
          .is_share_image
      ),

    site:
      Boolean(
        item.site
      ),

    yt:
      Boolean(
        item.yt
      ),

    concept:
      item.concept !==
      false,

    showcase:
      item.showcase !==
      false,

    client:
      item.client !==
      false,

    pin:
      item.pin !==
      false,

    analyzer_role:
      ANALYZER_ROLES.includes(
        analyzerRole
      )
        ? analyzerRole
        : "ignore",

    finder_start:
      FINDER_START_VALUES.includes(
        finderStart
      )
        ? finderStart
        : "auto",
  };
}


function upsertPlaylistSummary(
  current,
  row
) {
  const id =
    Number(
      row
        ?.playlist_id ||
      0
    );

  if (!id) {
    return current;
  }

  const exists =
    current.some(
      (item) =>
        Number(
          item
            ?.playlist_id ||
          0
        ) === id
    );

  if (
    exists
  ) {
    return current.map(
      (item) =>
        Number(
          item
            ?.playlist_id ||
          0
        ) === id
          ? {
              ...item,
              ...row,
            }
          : item
    );
  }

  return [
    ...current,
    row,
  ];
}


function getPhotoLibraryId(
  item
) {
  if (
    item
      ?.photo_library_id
  ) {
    return item
      .photo_library_id;
  }

  return (
    parsePhotoRef(
      item
        ?.image_url ||
      ""
    )
      .photoId
    ||
    ""
  );
}


function hasItemPhoto(
  item
) {
  return Boolean(
    String(
      getPhotoLibraryId(
        item
      ) ||
      ""
    ).trim()
    ||
    String(
      item
        ?.image_url ||
      ""
    ).trim()
  );
}


function getItemPhotoThumb(
  item,
  photoThumbs
) {
  const photoId =
    String(
      getPhotoLibraryId(
        item
      ) ||
      ""
    ).trim();

  if (
    photoId
    &&
    photoThumbs[
      photoId
    ]
  ) {
    return photoThumbs[
      photoId
    ];
  }

  const parsed =
    parsePhotoRef(
      item
        ?.image_url ||
      ""
    );

  if (
    parsed.url
  ) {
    return parsed.url;
  }

  if (
    item
      ?.image_url
    &&
    !String(
      item.image_url
    ).startsWith(
      "photo:"
    )
  ) {
    return item
      .image_url;
  }

  return "";
}


function getDisplayPaletteInfo(
  item,
  photoInfo
) {
  const photoId =
    String(
      getPhotoLibraryId(
        item
      ) ||
      ""
    ).trim();

  const info =
    photoInfo[
      photoId
    ]
    ||
    null;

  if (!info) {
    return null;
  }

  if (
    String(
      info
        .attachedSavedPalettePhotoType ||
      ""
    ).toLowerCase() ===
    "before"
  ) {
    return null;
  }

  return info;
}


function photoInfoFromRow(
  row = {}
) {
  return {
    attachedSavedPaletteId:
      row?.palette_id ?? row?.attached_saved_palette_id ?? null,

    attachedSavedPaletteLabel:
      row
        ?.attached_saved_palette_label
      ||
      "",





    attachedSavedPalettePhotoType:
      row
        ?.attached_saved_palette_photo_type
      ||
      "",

    clientId:
      row
        ?.client_id
      ??
      null,

    clientName:
      row
        ?.client_name
      ||
      "",

    clientEmail:
      row
        ?.client_email
      ||
      "",

    photoPermissionStatus:
      row
        ?.photo_permission_status
      ||
      "unknown",
  };
}


function itemIndex(
  items,
  item
) {
  return items.findIndex(
    (row) =>
      row
        ._clientKey ===
      item
        ?._clientKey
  );
}


function slideUsageLabel(
  item
) {
  const values = [];

  if (
    item.site !==
    false
  ) {
    values.push(
      "Site"
    );
  }

  if (
    item.concept !==
    false
  ) {
    values.push(
      "Concept"
    );
  }

  if (
    item.showcase !==
    false
  ) {
    values.push(
      "Showcase"
    );
  }

  if (
    item.client !==
    false
  ) {
    values.push(
      "Client"
    );
  }

  if (
    item.pin !==
    false
  ) {
    values.push(
      "Pin"
    );
  }

  if (
    item.yt !==
    false
  ) {
    values.push(
      "YT"
    );
  }

  return (
    values.join(
      " · "
    )
    ||
    "—"
  );
}


function slugifyPlaylistValue(
  value
) {
  return String(
    value ||
    ""
  )
    .toLowerCase()
    .trim()
    .replace(
      /[^a-z0-9]+/g,
      "-"
    )
    .replace(
      /-+/g,
      "-"
    )
    .replace(
      /^-|-$/g,
      ""
    );
}


function toDatetimeLocal(
  value
) {
  const text =
    String(
      value ||
      ""
    ).trim();

  if (!text) {
    return "";
  }

  return text
    .replace(
      " ",
      "T"
    )
    .slice(
      0,
      16
    );
}


function humanize(
  value
) {
  const raw =
    String(
      value ||
      ""
    )
      .trim();

  if (!raw) {
    return "—";
  }

  return raw
    .replace(
      /[_-]+/g,
      " "
    )
    .replace(
      /\b\w/g,
      (
        character
      ) =>
        character
          .toUpperCase()
    );
}
