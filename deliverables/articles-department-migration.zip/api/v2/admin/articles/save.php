<?php
declare(strict_types=1);

require_once __DIR__ . '/../auth.php'; // SYSTEM admin validation


if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(200); exit; }

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once __DIR__ . '/../../../autoload.php';
require_once __DIR__ . '/../../../db.php';

use App\ARTICLES\Controllers\ArticleController;
use App\ARTICLES\Repos\PdoArticleRepository;
use App\ARTICLES\Services\ArticleService;
use InvalidArgumentException;

function respond(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'POST') !== 'POST') {
    respond(['ok' => false, 'error' => 'POST only'], 405);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw ?: '', true);
if (!is_array($payload)) {
    respond(['ok' => false, 'error' => 'Invalid JSON'], 400);
}

try {
    $repo = new PdoArticleRepository($pdo);
    $service = new ArticleService($repo);
    $controller = new ArticleController($service);

    $articleId = $controller->save($payload);
    respond(['ok' => true, 'article_id' => $articleId]);
} catch (InvalidArgumentException $e) {
    respond(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    respond(['ok' => false, 'error' => $e->getMessage()], 500);
}
