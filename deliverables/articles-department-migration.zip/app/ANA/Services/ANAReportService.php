<?php
declare(strict_types=1);

namespace App\ANA\Services;

use App\ANA\Contracts\ANAReportRepositoryInterface;
use App\PLAYLISTS\Repos\PdoPlaylistRepository;
use App\ARTICLES\Repos\PdoArticleRepository;

final class ANAReportService
{
    public function __construct(
        private ANAReportRepositoryInterface $reports,
        private ?PdoPlaylistRepository $playlists = null,
        private ?PdoArticleRepository $articles = null,
    ) {}

    public function countEventsByResourceType(string $resourceType, string $eventKey): array
    {
        $rows = $this->reports->countEventsByResourceType($resourceType, $eventKey);

        if ($resourceType === 'outbound_link') {
            foreach ($rows as &$row) {
                $url = (string)($row['target_url'] ?? '');
                $host = parse_url($url, PHP_URL_HOST);
                $row['title'] = $host ? (str_contains(strtolower($host), 'youtube.com') || strtolower($host) === 'youtu.be' ? 'YouTube' : $host) : 'Outbound link';
            }
            unset($row);
            return $rows;
        }

        if ($resourceType === 'page') {
            foreach ($rows as &$row) {
                $pageId = (int)($row['resource_id'] ?? 0);
                $row['title'] = trim((string)($row['title'] ?? '')) ?: "Page #{$pageId}";
            }
            unset($row);
            return $rows;
        }

        if ($resourceType === 'article' && $this->articles !== null) {
            foreach ($rows as &$row) {
                $articleId = (int)($row['resource_id'] ?? 0);
                $article = $articleId > 0 ? $this->articles->getArticleById($articleId) : null;
                $row['title'] = $article['title'] ?? "Article #{$articleId}";
            }
            unset($row);
            return $rows;
        }

        if ($resourceType !== 'playlist' || $this->playlists === null) return $rows;
        foreach ($rows as &$row) {
            $playlistId = (int)($row['resource_id'] ?? 0);
            $playlist = $playlistId > 0 ? $this->playlists->getAdminRowById($playlistId) : null;
            $row['title'] = $playlist['title'] ?? "Playlist #{$playlistId}";
        }
        unset($row);
        return $rows;
    }

    public function listResourceTypes(): array { return $this->reports->listResourceTypes(); }

    public function countPlaylistEngagement(): array
    {
        $rows = $this->reports->countPlaylistEngagement();
        if ($this->playlists === null) return $rows;
        foreach ($rows as &$row) {
            $playlistId = (int)($row['resource_id'] ?? 0);
            $playlist = $playlistId > 0 ? $this->playlists->getAdminRowById($playlistId) : null;
            $row['title'] = $playlist['title'] ?? "Playlist #{$playlistId}";
            $opens = (int)($row['opens'] ?? 0);
            $watchMore = (int)($row['watch_more'] ?? 0);
            $row['watch_more_rate'] = $opens > 0 ? round(($watchMore / $opens) * 100, 1) : 0;
        }
        unset($row);
        return $rows;
    }

    public function listEventsForResource(string $resourceType, ?int $resourceId, string $eventKey, ?string $sourceLabel, ?string $targetUrl = null): array
    {
        return $this->reports->listEventsForResource($resourceType, $resourceId, $eventKey, $sourceLabel, $targetUrl);
    }

    public function deleteEventById(int $id): bool { return $this->reports->deleteEventById($id); }
}
