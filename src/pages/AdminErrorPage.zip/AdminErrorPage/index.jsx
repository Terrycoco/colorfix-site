export { default } from "./AdminErrorPage";
