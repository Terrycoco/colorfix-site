import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AdminDetailPane,
  AdminEmptyState,
  AdminListPane,
  AdminMasterDetail,
  AdminObjectList,
  AdminObjectListItem,
} from "@components/AdminLayout";
import FetchRexButton from "@components/REX/FetchRexButton";
import RexManagementDialog from "@components/REX/RexManagementDialog";
import { API_FOLDER } from "@helpers/config";
import "./AdminRexConversionPage.css";

const PLAYLISTS_URL = `${API_FOLDER}/v2/admin/playlists/list.php`;
const INSTANCES_URL = `${API_FOLDER}/v2/admin/playlist-instances/list.php`;
const REX_PLAYLISTS_URL = `${API_FOLDER}/v2/admin/rex/playlist-summary.php`;

async function readJsonResponse(response, fallbackMessage) {
  const text = await response.text();

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 200)}`);
  }

  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`${fallbackMessage}: invalid JSON response`);
  }

  if (!data?.ok) {
    throw new Error(data?.error || fallbackMessage);
  }

  return data;
}

function playlistTitleFromMap(playlistMap, playlistId) {
  const row = playlistMap.get(Number(playlistId));
  return row?.title || `Playlist #${playlistId}`;
}

function migrationAdminNote(instance) {
  const notes = String(instance?.instance_notes || "").trim();
  return notes
    ? `Migrated from PI #${instance.playlist_instance_id} — ${notes}`
    : `Migrated from PI #${instance.playlist_instance_id}`;
}

function migrationRequest(instance, playlistMap) {
  const playlistId = Number(instance?.playlist_id || 0);
  const playlistTitle = playlistTitleFromMap(playlistMap, playlistId);
  const instanceName = String(instance?.instance_name || "").trim();
  const slug = String(instance?.slug || "").trim();

  return {
    label: instanceName || `${playlistTitle} — migrated PI #${instance?.playlist_instance_id || ""}`,
    sourceKey: "",
    resolverKey: "playlist_experience",
    resourceType: "playlist",
    resourceId: playlistId,
    context: {
      experience_key: "public",
    },
    alias: slug,
    adminNote: migrationAdminNote(instance),
  };
}

export default function AdminRexConversionPage() {
  const [playlists, setPlaylists] = useState([]);
  const [instances, setInstances] = useState([]);
  const [rexPlaylists, setRexPlaylists] = useState([]);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [rexDialog, setRexDialog] = useState({
    open: false,
    reservationIds: [],
    title: "",
  });

  const playlistMap = useMemo(() => {
    const map = new Map();

    playlists.forEach((playlist) => {
      const id = Number(playlist?.playlist_id || 0);
      if (id > 0) {
        map.set(id, playlist);
      }
    });

    return map;
  }, [playlists]);

  const loadRexPlaylists = useCallback(async () => {
    const data = await readJsonResponse(
      await fetch(`${REX_PLAYLISTS_URL}?_=${Date.now()}`, {
        credentials: "include",
      }),
      "Failed to load REX playlists"
    );

    const items = Array.isArray(data.items) ? data.items : [];
    setRexPlaylists(items);

    setSelectedPlaylistId((current) => {
      if (current && items.some((item) => Number(item.playlist_id) === Number(current))) {
        return current;
      }

      return items[0]?.playlist_id ?? null;
    });

    return items;
  }, []);

  const loadPage = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const [playlistData, instanceData] = await Promise.all([
        readJsonResponse(
          await fetch(`${PLAYLISTS_URL}?limit=500&_=${Date.now()}`, {
            credentials: "include",
          }),
          "Failed to load playlists"
        ),
        readJsonResponse(
          await fetch(`${INSTANCES_URL}?active=1&_=${Date.now()}`, {
            credentials: "include",
          }),
          "Failed to load playlist instances"
        ),
      ]);

      setPlaylists(Array.isArray(playlistData.items) ? playlistData.items : []);
      setInstances(Array.isArray(instanceData.items) ? instanceData.items : []);

      await loadRexPlaylists();
    } catch (err) {
      setError(err?.message || "Failed to load REX conversion data");
    } finally {
      setLoading(false);
    }
  }, [loadRexPlaylists]);

  useEffect(() => {
    void loadPage();
  }, [loadPage]);

  async function handleRexCreated(instance, result) {
    setStatus(
      `REX #${result.reservationId} created for Playlist #${instance.playlist_id}.`
    );
    setError("");

    try {
      await loadRexPlaylists();
      setSelectedPlaylistId(Number(instance.playlist_id));
    } catch (err) {
      setError(err?.message || "REX was created, but the playlist summary could not refresh.");
    }
  }

  return (
    <div className="admin-rex-conversion">
      <AdminMasterDetail
        storageKey="admin-rex-conversion-list-width"
        defaultListWidth={320}
        minListWidth={260}
        maxListWidth={500}
        list={
          <AdminListPane title="REX Playlists">
            {loading ? (
              <AdminEmptyState title="Loading REX playlists" />
            ) : rexPlaylists.length === 0 ? (
              <AdminEmptyState
                title="No REX playlists yet"
                message="Use Fetch REX on a legacy Playlist Instance to begin."
              />
            ) : (
              <AdminObjectList ariaLabel="REX playlists">
                {rexPlaylists.map((playlist) => {
                  const ids = Array.isArray(playlist.rex) ? playlist.rex : [];
                  const count = ids.length;

                  return (
                    <AdminObjectListItem
                      key={playlist.playlist_id}
                      id={playlist.playlist_id}
                      title={playlist.title || `Playlist #${playlist.playlist_id}`}
                      meta={[
                        playlist.type || "",
                        Array.isArray(playlist.sources) && playlist.sources.length
                          ? `Sources: ${playlist.sources.join(", ")}`
                          : "",
                      ]}
                      selected={Number(selectedPlaylistId) === Number(playlist.playlist_id)}
                      status={{
                        active: count > 0,
                        count,
                        label: `${count} active REX reservation${count === 1 ? "" : "s"}`,
                      }}
                      onSelect={() => setSelectedPlaylistId(playlist.playlist_id)}
                      onStatusClick={() => {
                        if (!ids.length) return;

                        setRexDialog({
                          open: true,
                          reservationIds: ids,
                          title: playlist.title || `Playlist #${playlist.playlist_id}`,
                        });
                      }}
                    />
                  );
                })}
              </AdminObjectList>
            )}
          </AdminListPane>
        }
        detail={
          <AdminDetailPane
            ariaLabel="Playlist Instance conversion grid"
            className="admin-rex-conversion__detail"
          >
            <div className="admin-rex-conversion__header">
              <div>
                <h1>REX Conversion</h1>
                <p>
                  Legacy Playlist Instances are migration clues only. Fetch REX creates
                  reservations on the underlying Playlist.
                </p>
              </div>
            </div>

            {error ? (
              <div className="admin-rex-conversion__message admin-rex-conversion__message--error">
                {error}
              </div>
            ) : null}

            {status ? (
              <div className="admin-rex-conversion__message admin-rex-conversion__message--status">
                {status}
              </div>
            ) : null}

            {loading ? (
              <AdminEmptyState title="Loading Playlist Instances" />
            ) : instances.length === 0 ? (
              <AdminEmptyState
                title="No active Playlist Instances"
                message="There is nothing left in the active PI migration queue."
              />
            ) : (
              <div className="admin-rex-conversion__grid-wrap">
                <table className="admin-rex-conversion__grid">
                  <thead>
                    <tr>
                      <th>PI ID</th>
                      <th>Instance name</th>
                      <th>Playlist</th>
                      <th>Notes</th>
                      <th>Slug</th>
                      <th aria-label="Action" />
                    </tr>
                  </thead>

                  <tbody>
                    {instances.map((instance) => {
                      const playlistId = Number(instance.playlist_id || 0);
                      const playlistTitle = playlistTitleFromMap(playlistMap, playlistId);

                      return (
                        <tr key={instance.playlist_instance_id}>
                          <td className="admin-rex-conversion__id">
                            #{instance.playlist_instance_id}
                          </td>

                          <td>
                            {instance.instance_name || "—"}
                          </td>

                          <td>
                            <span className="admin-rex-conversion__playlist-title">
                              {playlistTitle}
                            </span>
                            <span className="admin-rex-conversion__playlist-id">
                              #{playlistId}
                            </span>
                          </td>

                          <td className="admin-rex-conversion__notes">
                            {instance.instance_notes || "—"}
                          </td>

                          <td className="admin-rex-conversion__slug">
                            {instance.slug || "—"}
                          </td>

                          <td className="admin-rex-conversion__action">
                            <FetchRexButton
                              request={migrationRequest(instance, playlistMap)}
                              buttonLabel="Fetch REX"
                              disabled={playlistId <= 0}
                              onCreated={(result) => void handleRexCreated(instance, result)}
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </AdminDetailPane>
        }
      />

      <RexManagementDialog
        open={rexDialog.open}
        reservationIds={rexDialog.reservationIds}
        title={rexDialog.title}
        onClose={() => {
          setRexDialog({
            open: false,
            reservationIds: [],
            title: "",
          });
        }}
      />
    </div>
  );
}
