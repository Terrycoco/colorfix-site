import "./white-animated.css";

export default function WhiteAnimated({
  className = "",
  signatureProgress = null,
  style = {},
}) {
  const controlled = signatureProgress !== null
    && signatureProgress !== undefined
    && Number.isFinite(Number(signatureProgress));
  const progress = controlled ? clamp01(Number(signatureProgress)) : null;
  const signatureStyle = controlled
    ? {
        opacity: progress <= 0 ? 0 : 1,
        "--logo-signature-cover-x": `${(progress * 105).toFixed(3)}%`,
      }
    : undefined;
  const rootClass = [
    "colorfix-logo",
    "colorfix-logo--white",
    controlled ? "is-controlled" : "is-css-animated",
    className,
  ].filter(Boolean).join(" ");

  return (
    <div className={rootClass} style={style} aria-label="ColorFix by Terry">
      <span className="colorfix-logo__main" aria-hidden="true">
        <span className="colorfix-logo__color">Color</span>
        <span className="colorfix-logo__fix">Fix</span>
      </span>
      <span className="colorfix-logo__by" aria-hidden="true" style={signatureStyle}>
        <span>by</span>
        <span>Terry</span>
      </span>
    </div>
  );
}

function clamp01(value) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}
